﻿namespace Sapphire.XGenerator
{
    using Sapphire.Misc;
    using Sapphire.Resolver;
    using System.Collections.Generic;
    using System.Xml.Linq;

    public record IrFunction(Identifier Name, List<IrInstruction> Instructions, SourceLocation Location)
    {
        public override string ToString() => $"Function({Name}) @ {Location}";
    }
}
