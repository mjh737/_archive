﻿namespace Sapphire.XGenerator
{
    public record IrLiteral(int Value) : IrVal
    {
        public override string ToString() => $"Constant({Value})";
    }
}
