﻿namespace Sapphire.XGenerator
{
    public record IrVar(string Name) : IrVal
    {
        public override string ToString() => $"Var(\"{Name}\")";
    }
}
