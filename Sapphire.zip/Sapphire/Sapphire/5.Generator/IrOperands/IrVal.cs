﻿namespace Sapphire.XGenerator
{
    public abstract record IrVal
    {
        public static IrVal Unit { get; } = new IrUnit();

        private record IrUnit : IrVal
        {
            public override string ToString() => "Unit";
        }
    }
}
