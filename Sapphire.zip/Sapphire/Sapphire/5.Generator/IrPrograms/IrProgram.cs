﻿namespace Sapphire.XGenerator
{
    public record IrProgram(string Name, IrFunction Function)
    {
        public override string ToString() => $"Program({Name})";
    }
}
