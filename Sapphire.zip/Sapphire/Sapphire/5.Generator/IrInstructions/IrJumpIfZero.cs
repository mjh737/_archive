﻿namespace Sapphire.XGenerator
{
    public record IrJumpIfZero(string Target, IrVal Condition) : IrInstruction
    {
        public override string ToString() => $"JumpIfZero({Target}, {Condition})";
    }
}
