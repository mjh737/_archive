﻿namespace Sapphire.XGenerator
{
    public record IrJumpIfNotZero(string Target, IrVal Condition) : IrInstruction
    {
        public override string ToString() => $"JumpIfNotZero({Target}, {Condition})";
    }
}
