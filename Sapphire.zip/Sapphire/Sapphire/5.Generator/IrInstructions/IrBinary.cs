﻿namespace Sapphire.XGenerator
{
    public record IrBinary(
     IrBinaryOperator Operator,
     IrVal Source1,
     IrVal Source2,
     IrVal Destination
 ) : IrInstruction
    {
        public override string ToString() =>
            $"Binary({Operator}, {Source1}, {Source2}, {Destination})";
    }
}
