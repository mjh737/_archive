﻿namespace Sapphire.XGenerator
{
    using Sapphire.Misc;

    // Assignment IR
    public record IrCopy(IrVal Source, IrVal Destination, SourceLocation Location) : IrInstruction
    {
        public override string ToString() => $"copy {Source} → {Destination} @ {Location}";

    }
}
