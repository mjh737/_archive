﻿namespace Sapphire.XGenerator
{
    public record IrUnary(
    IrUnaryOperator Operator,
    IrVal Source,
    IrVal Destination
) : IrInstruction
    {
        public override string ToString() =>
            $"Unary({Operator}, {Source}, {Destination})";
    }
}
