﻿namespace Sapphire.XGenerator
{
    using Sapphire.Resolver;

    public record IrReturn(IrVal Value) : IrInstruction
    {
        public override string ToString() => $"Return({Value})";
    }

}
