﻿namespace Sapphire.XGenerator
{
    using Sapphire.Misc;
    using Sapphire.Parser;
    using System.Xml.Linq;

    internal record IrComment(string Text, SourceLocation Location, SemanticTags? SemanticTag = null) : IrInstruction
    {
        public override string ToString()
        {
            var tag = SemanticTag != null ? $"[{SemanticTag}] " : "";
            return $"// {tag}{Text}";
        }
    }

}