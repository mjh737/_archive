﻿namespace Sapphire.XGenerator
{
    public abstract record IrInstruction
    {
    }
}
