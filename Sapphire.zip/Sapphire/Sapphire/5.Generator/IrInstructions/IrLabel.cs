﻿namespace Sapphire.XGenerator
{
    public record IrLabel(string Identifier) : IrInstruction
    {
        public override string ToString() => $"Label({Identifier})";
    }
}
