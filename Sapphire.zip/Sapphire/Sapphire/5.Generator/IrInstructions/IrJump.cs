﻿namespace Sapphire.XGenerator
{
    public record IrJump(string Target) : IrInstruction
    {
        public override string ToString() => $"Jump({Target})";
    }
}
