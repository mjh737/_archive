﻿namespace Sapphire.XGenerator
{
    public record TacMov(IrVal Destination, IrVal Source) : IrInstruction;
}
