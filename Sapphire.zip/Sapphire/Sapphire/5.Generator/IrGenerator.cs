﻿namespace Sapphire.XGenerator
{
    using Sapphire.Exceptions;
    using Sapphire.Misc;
    using Sapphire.Parser;
    using Sapphire.Parser.BlockItems;
    using global::Sapphire.Parser.Expressions;
    using global::Sapphire.Parser.Statements;
    using Sapphire.Resolver;
    using Sapphire.Parser.Functions;
    using System;
    using System.Collections.Generic;
    using System.Linq; // added

    public class IrGenerator
    {
        public IrProgram Generate(AstProgram program)
        {
            return new IrProgram(program.Name, EmitFunction(program.Functions[0]));
        }

        public IrFunction EmitFunction(AstFunctionDeclaration function)
        {
            var variableMap = new VariableMap(); // new scope for this function
            variableMap.EnterScope(); // enter function-level scope

            List<IrInstruction> instructions = EmitBlocks(function.Body, variableMap);

            variableMap.ExitScope(); // clean up scope

            return new IrFunction(function.Name, instructions, function.Location);
        }

        private List<IrInstruction> EmitBlocks(AstBlock block, VariableMap variableMap)
        {
            var instructions = new List<IrInstruction>();

            variableMap.WithNewScope(() =>
            {
                foreach (var item in block.BlockItems)
                {
                    switch (item)
                    {
                        case AstBlockItem.StatementItem stmt:
                            EmitStatement(stmt.S, instructions, variableMap);
                            break;

                        case AstBlockItem.DeclarationItem decl:
                            EmitDeclaration(decl.D, instructions, variableMap);
                            break;

                        default:
                            throw new GeneratorException($"Unknown BlockItem type: {item.GetType()}");
                    }
                }
            });

            var lastStatementItem = block.BlockItems
                .OfType<AstBlockItem.StatementItem>()
                .LastOrDefault();

            bool endsWithReturn = lastStatementItem?.S is AstReturnStatement;

            if (!endsWithReturn)
            {
                var fallbackVal = InferFallbackReturn(block, instructions, variableMap);

                if (fallbackVal is IrVar fallbackVar)
                {
                    instructions.Add(new IrReturn(fallbackVar));
                }
                else
                {
                    instructions.Add(new IrReturn(new IrLiteral(0)));
                    instructions.Add(new IrComment(
                        "Fallback return: no variable inferred",
                        block.Location,
                        SemanticTags.DebugHint));
                }
            }


            return instructions;
        }

        private IrVal? InferFallbackReturn(AstBlock block, List<IrInstruction> instructions, VariableMap variableMap)
        {
            // Try last declared variable
            var lastDeclName = block.BlockItems
                .OfType<AstBlockItem.DeclarationItem>()
                .Select(d => d.D.Identifier.OriginalName)
                .LastOrDefault();

            if (lastDeclName != null)
            {
                try
                {
                    return variableMap.Resolve(lastDeclName, block.Location);
                }
                catch (ResolverException) { }
            }

            // Fallback: use last assigned variable if no declaration is found
            var lastAssigned = instructions
                .OfType<IrCopy>()
                .Select(copy => copy.Destination)
                .OfType<IrVar>()
                .LastOrDefault();

            return lastAssigned;
        }


        private IrVal EmitDeclaration(AstDeclaration dec, List<IrInstruction> instructions, VariableMap variableMap)
        {
            Identifier identifier = dec.Identifier; // already resolved

            // Register resolved identifier into current scope for lookup
            variableMap.AddResolved(identifier.OriginalName, identifier);

            Console.WriteLine($"Registered resolved identifier: {identifier.OriginalName} → {identifier.UniqueName}");

            IrVal expr = dec.Initializer == null
                ? IrVal.Unit
                : EmitExpression(dec.Initializer, "", instructions, variableMap);

            IrVal dest = new IrVar(identifier.UniqueName);
            instructions.Add(new IrCopy(expr, dest, dec.Location));

            return expr;
        }

        private IrVal EmitStatement(
            AstStatement stmt,
            List<IrInstruction> instructions,
            VariableMap variableMap,
            string? breakLabel = null,
            string? continueLabel = null)
        {
            switch (stmt)
            {
                case AstReturnStatement ret:
                    var result = EmitExpression(ret.Expression, Registers.EAX, instructions, variableMap);
                    instructions.Add(new IrReturn(result)); // or however your IR encodes return
                    return result;


                case AstExpressionStatement exp:
                    return EmitExpression(exp.Expression, "_", instructions, variableMap);

                case AstCompoundStatement compound:
                    EmitBlock(compound.Block, instructions, variableMap, breakLabel, continueLabel);
                    return IrVal.Unit;

                case AstIfStatement ifStatement:
                    return EmitIfStatement(ifStatement, instructions, variableMap, breakLabel, continueLabel);

                case AstForStatement forStatement:
                    return EmitForStatement(forStatement, instructions, variableMap, breakLabel, continueLabel);

                case AstDoWhileStatement doStatement:
                    return EmitDoWhileLoop(doStatement, instructions, variableMap, breakLabel, continueLabel);

                case AstWhileStatement whileStatement:
                    // Always generate fresh labels for this while; do not reuse outer ones
                    return EmitWhileStatement(whileStatement, instructions, variableMap, outerBreakLabel: null, outerContinueLabel: null);

                case AstBreakStatement breakStatement:
                    return EmitBreakStatement(breakStatement, instructions, breakLabel);

                case AstContinueStatement continueStatement:
                    return EmitContinueStatement(continueStatement, instructions, continueLabel);

                case AstNullStatement nullStatement:
                    EmitNullStatement(nullStatement, instructions);
                    return IrVal.Unit;

                default:
                    throw new GeneratorException($"Unexpected statement: {stmt}");
            }
        }

        private IrVal EmitWhileStatement(
            AstWhileStatement whileStatement,
            List<IrInstruction> instructions,
            VariableMap variableMap,
            string? outerBreakLabel = null,
            string? outerContinueLabel = null)
        {
            // Generate local labels if none are provided
            string breakLabel = outerBreakLabel ?? VariableMap.MakeLabel($"break_{whileStatement.Location.StartLine}");
            string continueLabel = outerContinueLabel ?? VariableMap.MakeLabel($"continue_{whileStatement.Location.StartLine}");

            variableMap.WithNewScope(() =>
            {
                // Entry point for loop re-evaluation
                instructions.Add(new IrLabel(continueLabel));

                // Condition check
                IrVal condition = EmitExpression(whileStatement.Condition, "_", instructions, variableMap);
                instructions.Add(new IrJumpIfZero(breakLabel, condition));

                // Emit body with threaded labels
                EmitStatement(whileStatement.Body, instructions, variableMap, breakLabel, continueLabel);

                // Loop back
                instructions.Add(new IrJump(continueLabel));
            });

            // Exit point
            instructions.Add(new IrLabel(breakLabel));

            return IrVal.Unit;
        }

        private IrVal EmitDoWhileLoop(
            AstDoWhileStatement doStatement,
            List<IrInstruction> instructions,
            VariableMap variableMap,
            string? outerBreakLabel = null,
            string? outerContinueLabel = null)
        {
            string loopStartLabel = VariableMap.MakeLabel($"do_start_{doStatement.Location.StartLine}");
            string loopConditionLabel = VariableMap.MakeLabel($"do_condition_{doStatement.Location.StartLine}");
            string loopExitLabel = VariableMap.MakeLabel($"do_after_{doStatement.Location.StartLine}");

            instructions.Add(new IrComment("Entering do-while loop", doStatement.Location, SemanticTags.DebugHint ));

            variableMap.WithNewScope(() =>
            {
                // Loop entry
                instructions.Add(new IrLabel(loopStartLabel));

                // Emit loop body
                EmitStatement(
                    doStatement.Body,
                    instructions,
                    variableMap,
                    breakLabel: loopExitLabel,
                    continueLabel: loopConditionLabel // continue jumps to condition
                );

                // Emit condition only if body doesn't break unconditionally
                if (!IsUnconditionallyBreaking(doStatement.Body))
                {
                    instructions.Add(new IrLabel(loopConditionLabel));
                    IrVal condition = EmitExpression(doStatement.Condition, "_", instructions, variableMap);
                    instructions.Add(new IrComment($"Condition evaluated: {doStatement.Condition}", doStatement.Location, SemanticTags.DebugHint));
                    instructions.Add(new IrJumpIfNotZero(loopStartLabel, condition));
                }

            });

            // Loop exit
            instructions.Add(new IrLabel(loopExitLabel));

            // Emit return of variable 'a' (or whatever your return value is)
            var syntheticBlock = new AstBlock(
                new List<AstBlockItem> { new AstBlockItem.StatementItem(doStatement.Body) },
                doStatement.Location);

            var fallbackVal = InferFallbackReturn(syntheticBlock, instructions, variableMap);

            if (fallbackVal is IrVar fallbackVar)
            {
                instructions.Add(new IrReturn(fallbackVar));
            }
            else
            {
                instructions.Add(new IrReturn(new IrLiteral(0)));
                instructions.Add(new IrComment(
                    "Fallback return: no variable inferred",
                    doStatement.Location,
                    SemanticTags.DebugHint));
            }



            return IrVal.Unit;
        }

        private bool IsUnconditionallyBreaking(AstStatement stmt)
        {
            var syntheticBlock = new AstBlock(
                new List<AstBlockItem> { new AstBlockItem.StatementItem(stmt) },
                stmt.Location);

            var lastStmt = syntheticBlock.BlockItems
                .OfType<AstBlockItem.StatementItem>()
                .LastOrDefault()?.S;

            return lastStmt is AstBreakStatement;
        }


        private IrVal EmitContinueStatement(
            AstContinueStatement continueStatement,
            List<IrInstruction> instructions,
            string? continueLabel)
        {
            if (continueLabel == null)
            {
                throw new GeneratorException(
                    $"Invalid 'continue' at line {continueStatement.Location.StartLine}: not inside a loop");
            }

            instructions.Add(new IrComment($"Continue → {continueLabel}", continueStatement.Location, SemanticTags.DebugHint));
            instructions.Add(new IrJump(continueLabel));
            return IrVal.Unit;
        }

        private IrVal EmitBreakStatement(
            AstBreakStatement breakStatement,
            List<IrInstruction> instructions,
            string? breakLabel)
        {
            if (breakLabel == null)
            {
                throw new GeneratorException(
                    $"Invalid 'break' at line {breakStatement.Location.StartLine}: not inside a loop or switch");
            }

            instructions.Add(new IrJump(breakLabel));
            return IrVal.Unit;
        }


        private IrVal EmitForStatement(
            AstForStatement forStatement,
            List<IrInstruction> instructions,
            VariableMap variableMap,
            string? outerBreakLabel = null,
            string? outerContinueLabel = null)
        {
            string breakLabel = VariableMap.MakeLabel($"break_{forStatement.Location.StartLine}");
            string continueLabel = VariableMap.MakeLabel($"continue_{forStatement.Location.StartLine}");
            string startLabel = VariableMap.MakeLabel($"start_{forStatement.Location.StartLine}");

            // Create a new scope for the entire loop
            variableMap.WithNewScope(() =>
            {
                // Emit initializer (if any)
                if (forStatement.Init != null)
                {
                    EmitForInit(forStatement.Init, instructions, variableMap);
                }

                // Start of loop
                instructions.Add(new IrLabel(startLabel));

                // Emit condition check
                if (forStatement.Condition != null)
                {
                    IrVal condition = EmitExpression(forStatement.Condition, "_", instructions, variableMap);
                    instructions.Add(new IrJumpIfZero(breakLabel, condition));
                }

                // Emit body with threaded labels
                EmitStatement(forStatement.Body, instructions, variableMap, breakLabel, continueLabel);

                // Continue label (target for 'continue')
                instructions.Add(new IrLabel(continueLabel));

                // Emit post-expression
                if (forStatement.Post != null)
                {
                    EmitExpression(forStatement.Post, "_", instructions, variableMap);
                }

                // Jump back to start
                instructions.Add(new IrJump(startLabel));
            });

            // Break label (exit point)
            instructions.Add(new IrLabel(breakLabel));

            return IrVal.Unit;
        }

        private IrVal EmitForInit(AstForInit init, List<IrInstruction> instructions, VariableMap variableMap)
        {
            switch (init)
            {
                case AstForInitDecl decl:
                    {
                        string originalName = decl.Identifier.OriginalName;
                        variableMap.Add(originalName, decl.Initializer.Location);

                        Identifier identifier = variableMap.Resolve(originalName, decl.Initializer.Location);
                        IrVar variable = new IrVar(identifier.UniqueName);

                        IrVal value = EmitExpression(decl.Initializer, "_", instructions, variableMap);
                        instructions.Add(new IrCopy(value, variable, decl.Initializer.Location));

                        return IrVal.Unit;
                    }

                case AstForInitExp expr:
                    return EmitExpression(expr.Expression, "_", instructions, variableMap);

                default:
                    return IrVal.Unit;
            }
        }

        private void EmitNullStatement(AstNullStatement nullStatement, List<IrInstruction> instructions)
        {
            // Optionally: annotate or log the location
            Console.WriteLine($"[Emit] Null statement at {nullStatement.Location}");
        }

        private void EmitBlock(
            AstBlock block,
            List<IrInstruction> instructions,
            VariableMap variableMap,
            string? breakLabel = null,
            string? continueLabel = null)
        {
            variableMap.WithNewScope(() =>
            {
                foreach (var item in block.BlockItems)
                {
                    switch (item)
                    {
                        case AstBlockItem.StatementItem stmtItem:
                            EmitStatement(stmtItem.S, instructions, variableMap, breakLabel, continueLabel);
                            break;

                        case AstBlockItem.DeclarationItem declItem:
                            EmitDeclaration(declItem.D, instructions, variableMap);
                            break;

                        default:
                            throw new GeneratorException($"Unknown BlockItem type: {item.GetType()}");
                    }
                }
            });
        }

        private IrVal EmitIfStatement(
            AstIfStatement ifStatement,
            List<IrInstruction> instructions,
            VariableMap variableMap,
            string? breakLabel = null,
            string? continueLabel = null)
        {
            // Evaluate the condition
            IrVal condition = EmitExpression(ifStatement.Condition, "_", instructions, variableMap);

            // Create labels for else and end
            string elseLabel = VariableMap.MakeLabel("if_else");
            string endLabel = VariableMap.MakeLabel("if_end");

            // Branch to else if condition == 0
            instructions.Add(new IrJumpIfZero(elseLabel, condition));

            // Then branch
            EmitStatement(ifStatement.TrueBranch, instructions, variableMap, breakLabel, continueLabel);

            // Jump to end after then-branch (safe even if then-branch returns; becomes dead code)
            instructions.Add(new IrJump(endLabel));

            // Else label and branch
            instructions.Add(new IrLabel(elseLabel));
            if (ifStatement.FalseBranch != null)
            {
                EmitStatement(ifStatement.FalseBranch, instructions, variableMap, breakLabel, continueLabel);
            }

            // End label
            instructions.Add(new IrLabel(endLabel));

            // Statement-level if produces no value
            return IrVal.Unit;
        }

        // What's the target parameter for?
        private IrVal EmitExpression(
            AstExpression expr,
            string target,
            List<IrInstruction> instructions,
            VariableMap variableMap)
        {
            switch (expr)
            {
                case AstConstantExpression c:
                    return new IrLiteral(c.Value);

                case AstUnaryExpression unary:
                    var src = EmitExpression(unary.Operand, target, instructions, variableMap);
                    var unName = VariableMap.MakeTemporaryVariable("tmp");
                    IrVal dstUnexp = new IrVar(unName);
                    instructions.Add(new IrUnary(ConvertUnOpToTacOperator(unary.UnaryOperator), src, dstUnexp));
                    return dstUnexp;

                case AstBinaryExpression binary:
                    // Short-circuit logical AND
                    if (binary.BinaryOperator == AstBinaryOperators.And)
                    {
                        IrVar resultAnd = new IrVar(VariableMap.MakeTemporaryVariable("tmp"));
                        string falseLbl = MakeLabel("and_false");
                        string endLbl = MakeLabel("and_end");

                        // Evaluate left; if zero, skip right
                        var leftVal = EmitExpression(binary.Operand1, target, instructions, variableMap);
                        instructions.Add(new IrJumpIfZero(falseLbl, leftVal));

                        // Only evaluate right if left was non-zero
                        var rightVal = EmitExpression(binary.Operand2, target, instructions, variableMap);
                        instructions.Add(new IrJumpIfZero(falseLbl, rightVal));

                        instructions.Add(new IrCopy(new IrLiteral(1), resultAnd, SourceLocation.Unknown));
                        instructions.Add(new IrJump(endLbl));
                        instructions.Add(new IrLabel(falseLbl));
                        instructions.Add(new IrCopy(new IrLiteral(0), resultAnd, SourceLocation.Unknown));
                        instructions.Add(new IrLabel(endLbl));
                        return resultAnd;
                    }

                    // Short-circuit logical OR
                    if (binary.BinaryOperator == AstBinaryOperators.Or)
                    {
                        IrVar resultOr = new IrVar(VariableMap.MakeTemporaryVariable("tmp"));
                        string trueLbl = MakeLabel("or_true");
                        string endLbl = MakeLabel("or_end");

                        // Evaluate left; if non-zero, true
                        var leftVal = EmitExpression(binary.Operand1, target, instructions, variableMap);
                        instructions.Add(new IrJumpIfNotZero(trueLbl, leftVal));

                        // Only evaluate right if left was zero
                        var rightVal = EmitExpression(binary.Operand2, target, instructions, variableMap);
                        instructions.Add(new IrJumpIfZero(trueLbl, rightVal));

                        // both zero => false
                        instructions.Add(new IrCopy(new IrLiteral(0), resultOr, SourceLocation.Unknown));
                        instructions.Add(new IrJump(endLbl));
                        instructions.Add(new IrLabel(trueLbl));
                        instructions.Add(new IrCopy(new IrLiteral(1), resultOr, SourceLocation.Unknown));
                        instructions.Add(new IrLabel(endLbl));
                        return resultOr;
                    }

                    var src1 = EmitExpression(binary.Operand1, target, instructions, variableMap);
                    var src2 = EmitExpression(binary.Operand2, target, instructions, variableMap);

                    var binName = VariableMap.MakeTemporaryVariable("tmp");
                    IrVal dstBinExp = new IrVar(binName);
                    instructions.Add(new IrBinary(ConvertBinOpToTacOperator(binary.BinaryOperator), src1, src2, dstBinExp));
                    return dstBinExp;

                case AstTernaryExpression ternary:
                    {
                        var condVal = EmitExpression(ternary.Condition, target, instructions, variableMap);

                        string labelFalse = VariableMap.MakeLabel("tern_false");
                        string labelEnd = VariableMap.MakeLabel("tern_end");

                        string resultName = VariableMap.MakeTemporaryVariable("tmp");
                        var resultVar = new IrVar(resultName);

                        instructions.Add(new IrJumpIfZero(labelFalse, condVal));

                        var trueVal = EmitExpression(ternary.TrueBranch, target, instructions, variableMap);
                        instructions.Add(new IrCopy(trueVal, resultVar, ternary.Location));
                        instructions.Add(new IrJump(labelEnd));

                        instructions.Add(new IrLabel(labelFalse));
                        var falseVal = EmitExpression(ternary.FalseBranch, target, instructions, variableMap);
                        instructions.Add(new IrCopy(falseVal, resultVar, ternary.Location));

                        instructions.Add(new IrLabel(labelEnd));

                        return resultVar;
                    }

                case AstVarExpression var:
                    {
                        // Resolve to the current scoped binding and use its unique name as a TAC variable
                        Identifier identifier = variableMap.Resolve(var.Identifier.OriginalName, var.Location);
                        return new IrVar(identifier.UniqueName);
                    }

                case AstAssignmentExpression ass:
                    {
                        var lhs = (AstVarExpression)ass.Expression1;
                        Identifier identifier = variableMap.Resolve(lhs.Identifier.OriginalName, lhs.Location);
                        var tacVar = new IrVar(identifier.UniqueName);

                        // Fast-path: i = (i OP X) -> emit directly into i
                        if (ass.Expression2 is AstBinaryExpression bin
                            && bin.Operand1 is AstVarExpression binLhs
                            && string.Equals(binLhs.Identifier.OriginalName, lhs.Identifier.OriginalName, StringComparison.Ordinal))
                        {
                            var src2Fast = EmitExpression(bin.Operand2, target, instructions, variableMap);
                            instructions.Add(new IrBinary(ConvertBinOpToTacOperator(bin.BinaryOperator), tacVar, src2Fast, tacVar));
                            return tacVar;
                        }

                        var result = EmitExpression(ass.Expression2, target, instructions, variableMap);
                        instructions.Add(new IrCopy(result, tacVar, ass.Location));
                        return tacVar;
                    }

                default:
                    throw new GeneratorException("Invalid Expression Type");
            }
        }

        private IrVar AddAndInstructions(List<IrInstruction> instructions, IrVal src1, IrVal src2)
        {
            // Use a unique temporary to avoid collisions across chained && or other expressions
            IrVar result = new IrVar(VariableMap.MakeTemporaryVariable("tmp"));

            string branchLabel = MakeLabel("and_false");
            string endLabel = MakeLabel("and_end");

            instructions.Add(new IrJumpIfZero(branchLabel, src1));
            instructions.Add(new IrJumpIfZero(branchLabel, src2));
            instructions.Add(new IrCopy(new IrLiteral(1), result, SourceLocation.Unknown));
            instructions.Add(new IrJump(endLabel));
            instructions.Add(new IrLabel(branchLabel));
            instructions.Add(new IrCopy(new IrLiteral(0), result, SourceLocation.Unknown));
            instructions.Add(new IrLabel(endLabel));

            return result;
        }

        private IrVar AddOrInstructions(List<IrInstruction> instructions, IrVal src1, IrVal src2)
        {
            // Use a unique temporary to avoid collisions across chained || or other expressions
            IrVar result = new IrVar(VariableMap.MakeTemporaryVariable("tmp"));

            string branchLabel = MakeLabel("or_true");
            string endLabel = MakeLabel("or_end");

            instructions.Add(new IrJumpIfNotZero(branchLabel, src1));
            instructions.Add(new IrJumpIfZero(branchLabel, src2));
            instructions.Add(new IrCopy(new IrLiteral(0), result, SourceLocation.Unknown));
            instructions.Add(new IrJump(endLabel));
            instructions.Add(new IrLabel(branchLabel));
            instructions.Add(new IrCopy(new IrLiteral(1), result, SourceLocation.Unknown));
            instructions.Add(new IrLabel(endLabel));

            return result;
        }

        private IrUnaryOperator ConvertUnOpToTacOperator(string op)
        {
            return op switch
            {
                AstUnaryOperators.Negate => IrUnaryOperator.Negate,
                AstUnaryOperators.Complement => IrUnaryOperator.Complement,
                AstUnaryOperators.Not => IrUnaryOperator.Not,
                _ => throw new GeneratorException("Invalid Operator Type")
            };
        }

        private IrBinaryOperator ConvertBinOpToTacOperator(string op)
        {
            return op switch
            {
                AstBinaryOperators.Add => IrBinaryOperator.Add,
                AstBinaryOperators.Subtract => IrBinaryOperator.Subtract,
                AstBinaryOperators.Multiply => IrBinaryOperator.Multiply,
                AstBinaryOperators.Divide => IrBinaryOperator.Divide,
                AstBinaryOperators.Modulo => IrBinaryOperator.Modulo,

                AstBinaryOperators.Equal => IrBinaryOperator.Equal,
                AstBinaryOperators.EqualEqual => IrBinaryOperator.EqualEqual,
                AstBinaryOperators.NotEqual => IrBinaryOperator.NotEqual,
                AstBinaryOperators.GreaterThan => IrBinaryOperator.GreaterThan,
                AstBinaryOperators.LessThan => IrBinaryOperator.LessThan,
                AstBinaryOperators.GreaterOrEqualTo => IrBinaryOperator.GreaterThanOrEqual,
                AstBinaryOperators.LessOrEqualTo => IrBinaryOperator.LessThanOrEqual,
                AstBinaryOperators.And => IrBinaryOperator.And,
                AstBinaryOperators.Or => IrBinaryOperator.Or,

                _ => throw new GeneratorException($"Invalid Operand {op}")
            };
        }
        private string MakeTemporary()
        {
            return VariableMap.MakeTemporaryVariable("tmp");
        }

        private string MakeLabel(string name)
        {
            return VariableMap.MakeLabel(name);
        }
    }
}
