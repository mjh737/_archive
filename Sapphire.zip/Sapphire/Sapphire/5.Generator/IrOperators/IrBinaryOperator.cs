﻿namespace Sapphire.XGenerator
{
    public enum IrBinaryOperator
    {
        Add,
        Subtract,
        Multiply,
        Divide,
        Modulo,

        And,
        Or,
        Equal,
        EqualEqual,
        NotEqual,
        GreaterThan,
        LessThan,
        GreaterThanOrEqual,
        LessThanOrEqual,
    }
}
