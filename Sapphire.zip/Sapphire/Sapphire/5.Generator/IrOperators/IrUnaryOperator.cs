﻿namespace Sapphire.XGenerator
{
    public enum IrUnaryOperator
    {
        Complement,
        Negate,
        Not
    }
}
