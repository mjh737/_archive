﻿namespace Sapphire.Parser
{
    using Sapphire.Misc;
    using Sapphire.Parser.Expressions;

    public interface ILocatable
    {
        SourceLocation Location { get; }
    }

}