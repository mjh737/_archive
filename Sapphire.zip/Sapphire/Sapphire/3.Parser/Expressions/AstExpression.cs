﻿namespace Sapphire.Parser.Expressions
{
    using Sapphire.Misc;
    using Sapphire.Parser;
    public abstract record AstExpression(SourceLocation Location) : ILocatable;
}
