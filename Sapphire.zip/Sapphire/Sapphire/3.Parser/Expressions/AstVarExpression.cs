﻿namespace Sapphire.Parser.Expressions
{
    using Sapphire.Misc;
    using Sapphire.Resolver;

    public record AstVarExpression(Identifier Identifier, SourceLocation Location) : AstExpression(Location)
    {
        public override string ToString()
        {
            return $"VarExpression({Identifier})";
        }
    }
}
