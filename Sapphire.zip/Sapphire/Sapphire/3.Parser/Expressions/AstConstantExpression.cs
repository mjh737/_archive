﻿namespace Sapphire.Parser.Expressions
{
    using Sapphire.Misc;

    public record AstConstantExpression(int Value, SourceLocation Location) : AstExpression(Location)
    {
        public override string ToString()
        {
            return $"Constant({Value})";
        }
    }
}
