﻿namespace Sapphire.Parser.Expressions
{
    using Sapphire.Resolver;

    public sealed record AstForInitDecl(Identifier Identifier, AstExpression? Initializer) : AstForInit
    {
        public override string ToString() => Initializer is null
            ? $"Declaration: {Identifier}"
            : $"Declaration: {Identifier} = {Initializer}";
    }

}
