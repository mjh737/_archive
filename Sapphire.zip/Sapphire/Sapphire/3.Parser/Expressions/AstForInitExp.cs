﻿namespace Sapphire.Parser.Expressions
{
    public record AstForInitExp(AstExpression? Expression) : AstForInit
    {
        public override string ToString() => "Expression";
    }
}