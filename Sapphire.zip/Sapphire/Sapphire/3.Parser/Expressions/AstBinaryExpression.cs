﻿namespace Sapphire.Parser.Expressions
{
    using Sapphire.Misc;

    public record AstBinaryExpression(string BinaryOperator, AstExpression Operand1, AstExpression Operand2, SourceLocation Location) : AstExpression(Location)
    {
        public override string ToString()
        {
            return $"Binary({BinaryOperator}({Operand1}, {Operand2}))";
        }
    }
}