﻿namespace Sapphire.Parser.Expressions
{
    public abstract record AstForInit
    {
    }
}
