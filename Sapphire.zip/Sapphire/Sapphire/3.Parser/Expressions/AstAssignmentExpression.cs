﻿namespace Sapphire.Parser.Expressions
{
    using Sapphire.Misc;

    public record AstAssignmentExpression(AstExpression Expression1, AstExpression Expression2, SourceLocation Location) : AstExpression(Location)
    {
        public override string ToString()
        {
            return $"Assignment({Expression1}, {Expression2})";
        }
    }

}