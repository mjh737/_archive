﻿namespace Sapphire.Parser.Expressions
{
    using Sapphire.Misc;

    public record AstTernaryExpression(AstExpression Condition, AstExpression TrueBranch, AstExpression FalseBranch, SourceLocation Location) : AstExpression(Location)
    {
        public override string ToString()
        {
            return $"Ternary({Condition}, {TrueBranch}, {FalseBranch})";
        }
    }
}
