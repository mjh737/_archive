﻿namespace Sapphire.Parser.Expressions
{
    using Sapphire.Misc;

    public record AstUnaryExpression(string UnaryOperator, AstExpression Operand, SourceLocation Location) : AstExpression(Location)
    {
        public override string ToString()
        {
            return $"Unary({UnaryOperator}, {Operand})";
        }
    }
}
