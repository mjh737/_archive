﻿namespace Sapphire.Parser.Expressions
{
    using Sapphire.Misc;

    public sealed record AstForInitNone() : AstForInit();
}
