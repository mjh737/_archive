﻿namespace Sapphire.Parser.Expressions
{
    using Sapphire.Misc;
    using Sapphire.Resolver;
    using System.Collections.Generic;

    public record AstFunctionCallExpression(Identifier Identifier, List<AstExpression> args, SourceLocation Location) : AstExpression(Location)
    {
        public override string ToString()
        {
            return $"FunctionCall({Identifier}, [{string.Join(", ", args)}])";
        }
    }
}
