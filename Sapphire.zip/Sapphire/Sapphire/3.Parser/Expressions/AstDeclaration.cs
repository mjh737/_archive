﻿using Sapphire.Misc;
using Sapphire.Parser.Expressions;
using Sapphire.Resolver;

public record AstDeclaration(Identifier Identifier, SourceLocation Location, AstExpression? Initializer = null) : AstBlockItem
{
    public override string ToString()
    {
        var expression = Initializer is null ? "" : $"{Initializer}";
        return $"Declaration(\n\t\t{Identifier}\n\t\t{expression})";
    }
}