﻿namespace Sapphire.Parser
{
    using Sapphire.Parser.Functions;

    public record AstProgram(string Name, List<AstFunctionDeclaration> Functions)
    {
        public AstProgram(string name, AstFunctionDeclaration function)
            : this(name, new List<AstFunctionDeclaration> { function }) { }

        public override string ToString()
        {
            return $"Program(";
        }
    }
}