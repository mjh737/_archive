﻿namespace Sapphire.Parser
{
    using Sapphire.Assembler.Instructions;
    using Sapphire.Exceptions;
    using Sapphire.Misc;
    using Sapphire.Parser.BlockItems;
    using Sapphire.Parser.Expressions;
    using Sapphire.Parser.Functions;
    using Sapphire.Parser.Statements;
    using Sapphire.Resolver;
    using Sapphire.XLexer;
    using System;
    using System.Collections.Generic;

    public class AstParser
    {
        private string _name = "";
        int index = 0;
        List<Token> _tokens;

        public AstParser(string name, List<Token> tokens)
        {
            _tokens = tokens;
            _name = name;

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();
            Console.WriteLine("==========================================================");
            Console.WriteLine();
            Console.WriteLine("\tPARSING...");
            Console.WriteLine();
        }

        public AstProgram Parse()
        {
            AstProgram program = ParseProgram();

            if (!IsAtEnd())
            {
                var token = PeekToken();
                throw new ParserException($"Unexpected token after function: '{token.Value}' (type: {token.Type})", token.Location);
            }


            return program;
        }

        public AstProgram ParseProgram()
        {
            AstFunctionDeclaration function = ParseFunction();

            return new AstProgram(_name, function);
        }

        private AstFunctionDeclaration ParseFunction()
        {
            Expect(TokenTypes.IntKeyword);
            Identifier identifier = GetIdentifierFromToken();
            Expect(TokenTypes.OpenBracket);
            Expect(TokenTypes.VoidKeyword);
            Expect(TokenTypes.CloseBracket);

            var location = PeekTokenLocation(); // before Expect
            Expect(TokenTypes.OpenCurlyBrace);

            var block = ParseBlock(location);


            ConsumeToken(); // Remove closing }

            return new AstFunctionDeclaration(identifier, block, location);
        }

        private AstBlock ParseBlock(SourceLocation location)
        {
            List<AstBlockItem> blockItems = new List<AstBlockItem>();

            while (PeekTokenType() != TokenTypes.CloseCurlyBrace)
            {
                Console.WriteLine($"\tParseBlock Peeked token: {PeekTokenType()}");

                AstBlockItem nextBlockItem = ParseBlockItem();
                blockItems.Add(nextBlockItem);
            }

            return new AstBlock(blockItems, location);
        }

        private AstBlockItem ParseBlockItem()
        {
            string tokenType = PeekTokenType();
            Token token = PeekToken();

            Console.WriteLine($"\tParseBlockItem: Token={tokenType} -> {(TokenTypes.IsTypeKeyword(tokenType) ? "Declaration" : "Statement")}");

            if (TokenTypes.IsTypeKeyword(token.Type))
                return AstBlockItem.FromDeclaration(ParseDeclaration());

            return AstBlockItem.FromStatement(ParseStatement());
        }

        private AstDeclaration ParseDeclaration()
        {
            Expect(TokenTypes.IntKeyword);
            Identifier identifier = GetIdentifierFromToken();

            Token token = PeekToken();

            if (token.Type == TokenTypes.Semicolon)
            {
                ConsumeToken();
                return new AstDeclaration(identifier, token.Location);
            }
            else if (token.Type == TokenTypes.Equal)
            {
                ConsumeToken();
                AstDeclaration declaration = new AstDeclaration(identifier, token.Location, ParseExpression());

                Expect(TokenTypes.Semicolon);

                return declaration;
            }
            else
            {
                throw new ParserException($"Invalid Declaration {identifier}", token.Location);
            }
        }

        private AstForInit ParseForInit()
        {
            if (PeekTokenType() == TokenTypes.IntKeyword)
            {
                ConsumeToken(); // Consume 'int'
                Identifier identifier = ExpectIdentifier();

                AstExpression? initializer = null;

                if (PeekTokenType() == TokenTypes.Equal)
                {
                    ConsumeToken(); // Consume '='
                    initializer = ParseExpression();
                }

                return new AstForInitDecl(identifier, initializer);
            }
            else
            {
                AstExpression expr = ParseExpression();

                return new AstForInitExp(expr);
            }
        }

        private AstStatement ParseStatement()
        {
            List<AstComment> leadingComments = new();

            while (PeekTokenType() == TokenTypes.Comment)
            {
                var commentToken = PeekToken(); // or CurrentToken, depending on your lexer API
                leadingComments.Add(new AstComment(commentToken.Value, commentToken.Location));
                ConsumeToken(); // now discard it after capturing
            }


            string token = PeekTokenType();

            Console.WriteLine($"\tParseStatement: Routing to -> {RouteLabel(token)}");

            if (token == TokenTypes.Semicolon)
            {
                var location = PeekTokenLocation();
                ConsumeToken(); // consume the semicolon
                return new AstNullStatement(location);
            }
            else if (token == TokenTypes.IfKeyword)
                return ParseIfStatement();
            else if (token == TokenTypes.DoKeyword)
                return ParseDoWhileStatement();
            else if (token == TokenTypes.WhileKeyword)
                return ParseWhileStatement();
            else if (token == TokenTypes.ForKeyword)
                return ParseForStatement();
            else if (token == TokenTypes.ReturnKeyword)
                return ParseReturnStatement();
            else if (token == TokenTypes.BreakKeyword)
                return ParseBreakStatement();
            else if (token == TokenTypes.ContinueKeyword)
                return ParseContinueStatement();
            else if (token == TokenTypes.OpenCurlyBrace)
                return ParseCompoundStatement();
            else if (TokenTypes.IsStatementStart(token))
                return ParseGeneralStatement();
            else
            {
                var expr = ParseExpression();
                Expect(TokenTypes.Semicolon); // ensure expression statements end properly
                return new AstExpressionStatement(expr, expr.Location);
            }
        }

        private AstStatement ParseBreakStatement()
        {
            var location = PeekTokenLocation();
            Expect(TokenTypes.BreakKeyword);

            Identifier label;
            if (PeekTokenType() == TokenTypes.Identifier)
            {
                var labelToken = Expect(TokenTypes.Identifier);
                label = Identifier.FromToken(labelToken);
            }
            else
            {
                // Provide a default synthetic identifier if no label is present
                label = new Identifier(string.Empty, string.Empty, SourceLocation.Synthetic());
            }

            Expect(TokenTypes.Semicolon);
            return new AstBreakStatement(label, location);
        }

        private AstStatement ParseContinueStatement()
        {
            var location = PeekTokenLocation();
            Expect(TokenTypes.ContinueKeyword);

            Identifier? label = null;
            if (PeekTokenType() == TokenTypes.Identifier)
            {
                var labelToken = Expect(TokenTypes.Identifier);
                label = Identifier.FromToken(labelToken);
            }

            Expect(TokenTypes.Semicolon);
            return new AstContinueStatement(label, location);
        }

        private string RouteLabel(string token) =>
            token switch
            {
                TokenTypes.ReturnKeyword => "Return",
                TokenTypes.IfKeyword => "If",
                TokenTypes.BreakKeyword => "Break",
                TokenTypes.ContinueKeyword => "Continue",
                _ => "General"
            };

        private AstStatement ParseCompoundStatement()
        {
            var location = PeekTokenLocation(); // Capture location of `{`
            Expect(TokenTypes.OpenCurlyBrace);  // Safely consume `{`


            List<AstBlockItem> blockItems = new();

            while (PeekTokenType() != TokenTypes.CloseCurlyBrace)
            {
                blockItems.Add(ParseBlockItem()); // ✅ Unified logic + wrapper
            }

            Expect(TokenTypes.CloseCurlyBrace); // Safely consume `}`

            return new AstCompoundStatement(new AstBlock(blockItems, location), location);
        }

        private AstStatement ParseGeneralStatement()
        {
            AstExpression expression = ParseExpression();
            Console.WriteLine($"\tParsed general statement expression:\n\t\t{expression} of type {expression.GetType().Name}");

            Expect(TokenTypes.Semicolon);

            return new AstExpressionStatement(expression, expression.Location);
        }

        private AstStatement ParseReturnStatement()
        {
            ConsumeToken();

            Console.WriteLine($"\tParseReturnStatement: token={PeekTokenType()}");

            AstExpression retVal = ParseExpression();
            Console.WriteLine($"\t{retVal}");
            Expect(TokenTypes.Semicolon);

            return new AstReturnStatement(retVal, retVal.Location);
        }

        private AstStatement ParseIfStatement()
        {
            Console.WriteLine("\tParseIfStatement: entering if with condition");

            var location = PeekTokenLocation(); // ✅ capture location of `if`
            Expect(TokenTypes.IfKeyword);

            Expect(TokenTypes.OpenBracket);
            AstExpression condition = ParseExpression();
            Expect(TokenTypes.CloseBracket);
            AstStatement then = ParseStatement();

            AstStatement? otherwise = null;

            if (PeekTokenType() == TokenTypes.ElseKeyword)
            {
                ConsumeToken();
                otherwise = ParseStatement();
            }

            return new AstIfStatement(condition, then, location, otherwise);
        }

        private AstStatement ParseWhileStatement()
        {
            Expect(TokenTypes.WhileKeyword);
            Expect(TokenTypes.OpenBracket);
            AstExpression condition = ParseExpression();
            Expect(TokenTypes.CloseBracket);
            AstStatement body = ParseStatement();

            // Construct labels for control flow
            var breakLabel = new Identifier("break", "", condition.Location);
            var continueLabel = new Identifier("continue", "", condition.Location);

            return new AstWhileStatement(condition, body, breakLabel, continueLabel, condition.Location);
        }


        private AstStatement ParseDoWhileStatement()
        {
            var location = PeekTokenLocation(); // capture location of `do`
            Expect(TokenTypes.DoKeyword);
            AstStatement body = ParseStatement();
            Expect(TokenTypes.WhileKeyword);
            Expect(TokenTypes.OpenBracket);
            AstExpression condition = ParseExpression();
            Expect(TokenTypes.CloseBracket);
            Expect(TokenTypes.Semicolon); // enforce semicolon

            // Construct placeholder Identifier for loop label
            var breakLabel = new Identifier("break", "", condition.Location);
            var continueLabel = new Identifier("continue", "", condition.Location);

            return new AstDoWhileStatement(body, condition, breakLabel, continueLabel, location);
        }

        private AstStatement ParseForStatement()
        {
            var location = PeekTokenLocation(); // ✅ capture location of `for`

            Expect(TokenTypes.ForKeyword);
            Expect(TokenTypes.OpenBracket);

            // 🔧 Parse optional init
            AstForInit init;
            if (PeekTokenType() == TokenTypes.Semicolon)
            {
                ConsumeToken(); // consume first semicolon
                init = new AstForInitNone(); // or whatever represents "no init"
            }
            else
            {
                init = ParseForInit();
                Expect(TokenTypes.Semicolon);
            }

            // 🔧 Parse optional condition
            AstExpression? condition = null;
            if (PeekTokenType() != TokenTypes.Semicolon)
            {
                condition = ParseExpression();
            }
            Expect(TokenTypes.Semicolon);

            // 🔧 Parse optional post
            AstExpression? post = null;
            if (PeekTokenType() != TokenTypes.CloseBracket)
            {
                post = ParseExpression();
            }
            Expect(TokenTypes.CloseBracket);

            AstStatement body = ParseStatement();

            var loopLabel = new Identifier(OriginalName: "loop", UniqueName: "", Location: location);


            return new AstForStatement(init, condition, post, body, loopLabel, location);
        }

        private AstExpression ParseExpression(int minimumPrecedence = 0)
        {
            AstExpression left = ParseFactor(); // already includes location

            while (AstBinaryOperators.Contains(PeekTokenType()))
            {
                // Map token -> AST operator and get its precedence
                Token opTokenPeek = PeekToken();
                string tokenType = opTokenPeek.Type;

                // Handle assignment separately (right-assoc)
                if (tokenType == TokenTypes.Equal)
                {
                    ConsumeToken();
                    var rightAssign = ParseExpression(Precedence.Of(AstBinaryOperators.Equal));
                    var locAssign = SourceLocation.Span(left.Location, rightAssign.Location);
                    left = new AstAssignmentExpression(left, rightAssign, locAssign);
                    continue;
                }

                // Handle ternary separately
                if (tokenType == TokenTypes.QuestionMark)
                {
                    ConsumeToken();
                    AstExpression middle = ParseTernaryMiddle();
                    var rightTern = ParseExpression(Precedence.Of(AstBinaryOperators.QuestionMark));
                    var locTern = SourceLocation.Span(left.Location, rightTern.Location);
                    left = new AstTernaryExpression(left, middle, rightTern, locTern);
                    continue;
                }

                // Convert to AST operator and compute precedence
                string op = ConvertTokenTypeToBinop(opTokenPeek);
                int prec = Precedence.Of(op);

                if (prec < minimumPrecedence)
                    break;

                ConsumeToken(); // consume the operator

                // Left-associative: parse RHS with prec+1
                var right = ParseExpression(prec + 1);
                var location = SourceLocation.Span(left.Location, right.Location);
                left = new AstBinaryExpression(op, left, right, location);
            }

            return left;
        }

        private AstExpression ParseTernaryMiddle()
        {
            Console.WriteLine($"\tParseTernary: Next Token is {PeekTokenType()}");

            AstExpression middle = ParseExpression(0);
            ConsumeToken();

            return middle;
        }

        private static readonly Dictionary<string, string> BinaryOperatorMap = new()
        {
            [TokenTypes.Multiply] = AstBinaryOperators.Multiply,
            [TokenTypes.Add] = AstBinaryOperators.Add,
            [TokenTypes.Divide] = AstBinaryOperators.Divide,
            [TokenTypes.Negate] = AstBinaryOperators.Subtract,
            [TokenTypes.Modulo] = AstBinaryOperators.Modulo,
            [TokenTypes.And] = AstBinaryOperators.And,
            [TokenTypes.Or] = AstBinaryOperators.Or,
            [TokenTypes.Equal] = AstBinaryOperators.Equal,
            [TokenTypes.EqualEqual] = AstBinaryOperators.EqualEqual,
            [TokenTypes.NotEqual] = AstBinaryOperators.NotEqual,
            [TokenTypes.GreaterThan] = AstBinaryOperators.GreaterThan,
            [TokenTypes.LessThan] = AstBinaryOperators.LessThan,
            [TokenTypes.GreaterOrEqualTo] = AstBinaryOperators.GreaterOrEqualTo,
            [TokenTypes.LessOrEqualTo] = AstBinaryOperators.LessOrEqualTo
        };

        private string ConvertTokenTypeToBinop(Token token)
        {
            if (BinaryOperatorMap.TryGetValue(token.Type, out var binop))
                return binop;

            throw new ParserException(
                $"Invalid binary operator token: {token.Type} '{token.Value}'",
                token.Location
            );
        }

        private AstExpression ParseFactor()
        {
            var nextToken = PeekTokenType();

            Console.WriteLine($"\tParseFactor: next={nextToken}");
            Console.WriteLine($"\tLookahead: {PeekTokenType(1)}, {PeekTokenType(2)}");

            if (nextToken == TokenTypes.Constant)
            {
                return ParseInt(); // already location-aware
            }
            else if (nextToken == TokenTypes.Identifier)
            {
                var token = PeekToken();
                ConsumeToken();

                return new AstVarExpression(token.ToIdentifier(), token.Location);
            }
            else if (AstUnaryOperators.Contains(nextToken))
            {
                var opToken = PeekToken();
                string unOp = ParseUnop();

                AstExpression innerExpression = ParseFactor();
                var location = SourceLocation.Span(opToken.Location, innerExpression.Location);

                return new AstUnaryExpression(unOp, innerExpression, location);
            }
            else if (nextToken == TokenTypes.OpenBracket)
            {
                var openToken = PeekToken();
                ConsumeToken();

                AstExpression innerExpression = ParseExpression();

                // We don’t get the close token directly, but we can assume it follows
                var closeToken = PeekToken(); // peek before Expect
                Expect(TokenTypes.CloseBracket);

                var location = SourceLocation.Span(openToken.Location, closeToken.Location);

                // Attach the span to the inner expression
                return innerExpression with { Location = location };
            }
            else
            {
                var token = PeekToken();
                throw new ParserException($"Malformed Factor: '{token.Value}' (type: {token.Type})", token.Location);
            }
        }

        private string ParseUnop()
        {
            Token token = _tokens[index++];
            return token.Type;
        }

        private AstVarExpression ParseIdentifier()
        {
            Token token = _tokens[index++];
            return new AstVarExpression(token.ToIdentifier(), token.Location);
        }

        private AstConstantExpression ParseInt()
        {
            Token token = _tokens[index++];
            bool result = int.TryParse(token.Value, out int integer);

            if (!result)
                throw new ParserException($"Expected an integer, but got '{token.Value}'", token.Location);

            return new AstConstantExpression(integer, token.Location);
        }

        private Identifier ExpectIdentifier() => GetIdentifierFromToken(); // It keep parser logic expressive and clear


        private Identifier GetIdentifierFromToken()
        {
            Token token = _tokens[index++];

            if (token.Type != TokenTypes.Identifier)
                throw new ParserException(
                    $"Expected identifier, got {token.Type} '{token.Value}'",
                    token.Location
                );

            return Identifier.FromToken(token);
        }

        private Token Expect(string tokenType)
        {
            var token = _tokens[index++];

            if (token.Type != tokenType)
                throw new ParserException(
                    $"Expected '{tokenType}', but got '{token.Value}'",
                    token.Location
                );

            return token;
        }

        private Token PeekToken(int skip = 0)
        {
            int peekIndex = index + skip;

            if (peekIndex >= _tokens.Count)
            {
                var last = _tokens.LastOrDefault();
                var location = last?.Location ?? SourceLocation.Unknown;

                throw new ParserException("No further tokens", location);
            }

            return _tokens[peekIndex];
        }

        private string PeekTokenValue(int skip = 0)
        {
            if (index + skip >= _tokens.Count)
                return TokenTypes.Invalid;

            Token actual = _tokens[index + skip];
            return actual.Value;
        }

        private string PeekTokenType(int skip = 0)
        {
            if (index + skip >= _tokens.Count)
                return TokenTypes.Invalid;

            Token actual = _tokens[index + skip];
            return actual.Type;
        }

        private SourceLocation PeekTokenLocation(int skip = 0)
        {
            if (index + skip >= _tokens.Count)
                return new SourceLocation(0,0,0,0);

            Token actual = _tokens[index + skip];
            return actual.Location;
        }

        private void ConsumeToken(string tokenType = "")
        {
            if (!string.IsNullOrEmpty(tokenType))
                Expect(tokenType);

            index++;
        }

        private bool IsAtEnd()
        {
            return index >= _tokens.Count; // || _tokens[index].Type == TokenTypes.EOF;
        }
    }
}
