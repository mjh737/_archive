﻿namespace Sapphire.Parser
{
    using Sapphire.XLexer;

    public static class AstBinaryOperators
    {
        public const string Add = "Add";
        public const string Subtract = "Subtract";
        public const string Multiply = "Multiply";
        public const string Divide = "Divide";
        public const string Modulo = "Modulo";

        public const string And = "And";
        public const string Or = "Or";
        public const string Equal = "Equal";
        public const string EqualEqual = "EqualEqual";
        public const string NotEqual = "NotEqual";
        public const string LessThan = "LessThan";
        public const string GreaterThan = "GreaterThan";
        public const string LessOrEqualTo = "LessOrEqualTo";
        public const string GreaterOrEqualTo = "GreaterOrEqualTo";

        public const string QuestionMark = "QuestionMark";

        public static bool Contains(string op)
        {
            return op == TokenTypes.Add
                || op == TokenTypes.Negate
                || op == TokenTypes.Multiply
                || op == TokenTypes.Divide
                || op == TokenTypes.And
                || op == TokenTypes.Or
                || op == TokenTypes.Equal
                || op == TokenTypes.EqualEqual
                || op == TokenTypes.NotEqual
                || op == TokenTypes.LessThan
                || op == TokenTypes.GreaterThan
                || op == TokenTypes.LessOrEqualTo
                || op == TokenTypes.GreaterOrEqualTo
                || op == TokenTypes.Modulo
                || op == TokenTypes.QuestionMark;
        }
    }
}
