﻿namespace Sapphire.Parser
{
    public static class AstUnaryOperators
    {
        public const string Complement = "Complement";
        public const string Negate = "Negate";
        public const string Not = "Not";

        public static bool Contains(string op)
        {
            return op == AstUnaryOperators.Complement || op == AstUnaryOperators.Negate || op == AstUnaryOperators.Not;
        }
    }
}