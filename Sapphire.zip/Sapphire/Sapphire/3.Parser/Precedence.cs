﻿namespace Sapphire
{
    using Sapphire.Parser;

    public static class Precedence
    {
        public static int Of(string op) => op switch
        {
            AstBinaryOperators.Multiply => 50,
            AstBinaryOperators.Divide => 50,
            AstBinaryOperators.Modulo => 50,
            AstBinaryOperators.Add => 45,
            AstBinaryOperators.Subtract => 45,

            AstBinaryOperators.LessThan => 35,
            AstBinaryOperators.LessOrEqualTo => 35,
            AstBinaryOperators.GreaterThan => 35,
            AstBinaryOperators.GreaterOrEqualTo => 35,
            AstBinaryOperators.EqualEqual => 30,
            AstBinaryOperators.NotEqual => 30,
            AstBinaryOperators.And => 10,
            AstBinaryOperators.Or => 5,
            AstBinaryOperators.QuestionMark => 3,
            AstBinaryOperators.Equal => 1,
            _ => 0,
        };
    }
}
