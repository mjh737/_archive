﻿namespace Sapphire.Parser
{
    public enum SemanticTags
    {
        LoopEntry,
        Condition,
        DebugHint
    }
}