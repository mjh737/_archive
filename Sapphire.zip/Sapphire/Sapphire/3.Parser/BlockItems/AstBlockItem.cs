﻿using Sapphire.Parser.Statements;

public abstract record AstBlockItem
{
    public static AstBlockItem FromStatement(AstStatement s) => new StatementItem(s);
    public static AstBlockItem FromDeclaration(AstDeclaration d) => new DeclarationItem(d);

    public sealed record StatementItem(AstStatement S) : AstBlockItem;
    public sealed record DeclarationItem(AstDeclaration D) : AstBlockItem;

    public override string ToString() => this switch
    {
        StatementItem s => $"S{s.S}",
        DeclarationItem d => $"D{d.D}",
        _ => throw new Exception("Invalid Block Content")
    };
}
