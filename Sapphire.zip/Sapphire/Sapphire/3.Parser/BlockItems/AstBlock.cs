﻿namespace Sapphire.Parser.BlockItems
{
    using Sapphire.Misc;

    public record AstBlock(List<AstBlockItem> BlockItems, SourceLocation Location)
    {
        public override string ToString()
        {
            var items = string.Join("\n    ", BlockItems.Select(item => item.ToString()));
            return $"AstBlock @ {Location}\n    {items}";
        }

    }
}
