﻿namespace Sapphire.Parser.Statements
{
    using Sapphire.Misc;

    public abstract record AstStatement(SourceLocation Location) : AstBlockItem, ILocatable;
}
