﻿namespace Sapphire.Parser.Statements
{
    using Sapphire.Misc;

    public record AstNullStatement(SourceLocation Location) : AstStatement(Location)
    {
        public override string ToString() => ";";
    }

}
