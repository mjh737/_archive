﻿namespace Sapphire.Parser.Statements
{
    using Sapphire.Misc;
    using Sapphire.Parser.Expressions;
    using Sapphire.Resolver;

    public record AstDoWhileStatement(
    AstStatement Body,
    AstExpression Condition,
    Identifier BreakLabel,
    Identifier ContinueLabel,
    SourceLocation Location
) : AstStatement(Location)
    {
        public override string ToString() => "DoWhile";
    }
}
