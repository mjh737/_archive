﻿namespace Sapphire.Parser.Statements
{
    using Sapphire.Misc;
    using Sapphire.Parser.Expressions;

    public record AstExpressionStatement(AstExpression Expression, SourceLocation Location) : AstStatement(Location)
    {
        public override string ToString() => "Statement(";
    }
}
