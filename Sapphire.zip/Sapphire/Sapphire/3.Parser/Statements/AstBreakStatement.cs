﻿namespace Sapphire.Parser.Statements
{
    using Sapphire.Misc;
    using Sapphire.Resolver;

    public record AstBreakStatement(Identifier Label, SourceLocation Location) : AstStatement(Location)
    {
        public override string ToString() => $"Break {Label.OriginalName}";

    }
}
