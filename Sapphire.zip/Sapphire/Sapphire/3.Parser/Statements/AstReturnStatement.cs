﻿namespace Sapphire.Parser.Statements
{
    using Sapphire.Misc;
    using Sapphire.Parser.Expressions;

    public record AstReturnStatement(AstExpression? Expression, SourceLocation Location) : AstStatement(Location)
    {
        public override string ToString()
        {
            return $"{Expression}";
        }
    }

}
