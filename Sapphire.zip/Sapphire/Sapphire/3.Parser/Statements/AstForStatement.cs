﻿namespace Sapphire.Parser.Statements
{
    using Sapphire.Misc;
    using Sapphire.Parser.Expressions;
    using Sapphire.Resolver;

    public record AstForStatement(
    AstForInit? Init,
    AstExpression? Condition,
    AstExpression? Post,
    AstStatement Body,
    Identifier Identifier,
    SourceLocation Location
) : AstStatement(Location)
    {
        public override string ToString() => "For";
    }
}
