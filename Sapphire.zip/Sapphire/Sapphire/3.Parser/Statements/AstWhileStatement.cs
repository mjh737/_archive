﻿namespace Sapphire.Parser.Statements
{
    using Sapphire.Misc;
    using Sapphire.Parser.Expressions;
    using Sapphire.Resolver;

    public record AstWhileStatement(
    AstExpression Condition,
    AstStatement Body,
    Identifier BreakLabel,
    Identifier ContinueLabel,
    SourceLocation Location
) : AstStatement(Location)
    {
        public override string ToString() => "While";
    }
}
