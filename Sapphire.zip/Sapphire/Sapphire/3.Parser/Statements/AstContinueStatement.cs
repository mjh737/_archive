﻿namespace Sapphire.Parser.Statements
{
    using Sapphire.Misc;
    using Sapphire.Resolver;

    public record AstContinueStatement(Identifier? Label, SourceLocation Location) : AstStatement(Location)
    {
        public override string ToString() =>
            Label is null
                ? $"continue @ {Location}"
                : $"continue {Label.OriginalName} @ {Location}";
    }

}
