﻿namespace Sapphire.Parser.Statements
{
    using Sapphire.Misc;
    using Sapphire.Parser.BlockItems;

    public record AstCompoundStatement(AstBlock Block, SourceLocation Location) : AstStatement(Location)
    {
        List<AstBlockItem> Items;
    }
}
