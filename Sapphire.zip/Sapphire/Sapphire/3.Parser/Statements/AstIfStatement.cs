﻿namespace Sapphire.Parser.Statements
{
    using Sapphire.Misc;
    using Sapphire.Parser.Expressions;

    public record AstIfStatement(AstExpression Condition, AstStatement TrueBranch, SourceLocation Location, AstStatement? FalseBranch = null) : AstStatement(Location)
    {
        public override string ToString() => "If";
    }
}
