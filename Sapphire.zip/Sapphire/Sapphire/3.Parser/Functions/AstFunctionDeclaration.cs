﻿namespace Sapphire.Parser.Functions
{
    using Sapphire.Misc;
    using Sapphire.Parser.BlockItems;
    using Sapphire.Resolver;

    public record AstFunctionDeclaration(Identifier Name, List<Identifier> parameters, AstBlock? Body, SourceLocation Location)
    {
        public override string ToString()
        {
            var indent = "    ";
            var bodyStr = Body?.ToString()
                              .Replace("\n", "\n" + indent); // Indent each line of the body

            return $"""
        Function: {Name.UniqueName}
        Location: Line {Location.StartLine}
        Parameters: {string.Join(", ", parameters.Select(p => p.UniqueName))}
        Body:
        {indent}{bodyStr}
        """;
        }
    }
}