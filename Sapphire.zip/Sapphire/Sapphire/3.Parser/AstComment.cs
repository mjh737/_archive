﻿namespace Sapphire.Parser
{
    using Sapphire.Misc;

    public record AstComment(
    string Text,
    SourceLocation Location,
    SemanticTags? SemanticTag = null 
);
}