﻿namespace Sapphire
{
    public static class Registers
    {
        public static string EAX = "eax";
        public static string EBX = "ebx";
        public static string ECX = "ecx";
        public static string EDX = "edx";
        public static string R10 = "r10d";
        public static string R11 = "r11d";
    }
}
