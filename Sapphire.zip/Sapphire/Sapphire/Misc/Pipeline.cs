﻿namespace Sapphire
{
    using Sapphire.Converter;
    using Sapphire.Parser;
    using Sapphire.Printers;
    using Sapphire.Replacer;
    using Sapphire.Resolver;
    using Sapphire.Rewriter;
    using Sapphire.Source;
    using Sapphire.XGenerator;
    using Sapphire.XLexer;
    using System.Collections.Generic;

    public class Pipeline
    {
        bool _stopAfterLexer = false;
        bool _stopAfterParser = false;
        bool _stopAfterCodeGen = false;

        public Pipeline(params string[] args)
        {
            _stopAfterLexer = args.Contains("--lex");
            _stopAfterParser = args.Contains("--parse");
            _stopAfterCodeGen = args.Contains("--codegen");

            //VariableMap.Reset();
        }

        public int ReadCompileAndDisplay(string inputFile)
        {
            string source = File.ReadAllText(inputFile);
            string progName = inputFile.Split("\\").Last().Split(".")[0];

            return CompileAndDisplay(progName, source);
        }

        public int CompileAndDisplay(string progName, string sourceCode)
        {
            Console.WriteLine($"Compiling listing: {progName} (hash={sourceCode.GetHashCode()})");

            try
            {
                // 1 SOURCE
                SourcePrinter sourcePrinter = new SourcePrinter();
                sourcePrinter.Print(sourceCode, progName);

                // 2 LEXER
                Lexer lexer = new Lexer();
                List<Token> tokens = lexer.Run(sourceCode);

                LexPrinter lexPrinter = new LexPrinter();
                lexPrinter.Print(tokens);

                if (_stopAfterLexer)
                    return 0;

                // 3 PARSER
                AstParser parser = new AstParser(progName, tokens);
                AstProgram ast = parser.Parse();
                Console.WriteLine();

                AstPrinter prettyPrinter = new AstPrinter();
                prettyPrinter.Print(ast);

                // RESOLVER
                VariableResolver resolver = new VariableResolver();
                AstProgram astResolved = resolver.Resolve(ast);

                ResolverPrinter resPrinter = new ResolverPrinter();
                resPrinter.Print(astResolved);

                // 4 ASM GENERATOR
                IrGenerator tacGen = new IrGenerator();
                IrProgram tacProg = tacGen.Generate(astResolved);

                IrPrinter tacPrinter = new IrPrinter();
                tacPrinter.Print(tacProg);

                // 5 CONVERTERS
                IrConverter tacToAsm = new IrConverter();
                AsmProgram asm = tacToAsm.Lower(tacProg);

                ConverterPrinter tacToAsmPrinter = new ConverterPrinter();
                tacToAsmPrinter.Print(asm);

                PseudoReplacer pseudoReplacer = new PseudoReplacer();
                asm = pseudoReplacer.Run(asm);
                int stackOffset = pseudoReplacer.StackOffset;

                ReplacerPrinter pseudoPrinter = new ReplacerPrinter();
                pseudoPrinter.Print(asm, stackOffset);

                InstructionRewriter rewriter = new InstructionRewriter();
                asm = rewriter.Run(asm, stackOffset);

                RewritePrinter rewritePrinter = new RewritePrinter();
                rewritePrinter.Print(asm);

                // 6 ASM EMITTER
                AsmEmitter emitter = new AsmEmitter();
                string code = emitter.Emit(asm);
                //emitter.WriteAsmToFile(output, code);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\t[Error] {progName} failed: {ex.Message}");
                throw; // bubble up to test harness or caller
            }

            return 0;
        }

        public int CompileAndWrite(string input)
        {
            // 1 SOURCE
            string source = File.ReadAllText(input);
            string listing = input.Split("/").Last();
            //string output = listing.Split(".").First() + ".asm";
            string output = "program.asm";
            
            string code = Compile(source, listing);
            File.WriteAllText(output, code);

            return 0;
        }

        private static string Compile(string source, string listing)
        {
            // 2 LEXER
            Lexer lexer = new Lexer();
            List<Token> tokens = lexer.Run(source);

            // 3 PARSER
            AstParser parser = new AstParser(listing, tokens);
            AstProgram ast = parser.Parse();

            // RESOLVER
            VariableResolver resolver = new VariableResolver();
            AstProgram astResolved = resolver.Resolve(ast);

            // 4 ASM GENERATOR
            IrGenerator tacGen = new IrGenerator();
            IrProgram tacProg = tacGen.Generate(astResolved);

            // 5 CONVERTERS
            IrConverter tacToAsm = new IrConverter();
            AsmProgram asm = tacToAsm.Lower(tacProg);

            PseudoReplacer pseudoReplacer = new PseudoReplacer();
            asm = pseudoReplacer.Run(asm);
            int stackOffset = pseudoReplacer.StackOffset;

            InstructionRewriter rewriter = new InstructionRewriter();
            asm = rewriter.Run(asm, stackOffset);

            // 6 ASM EMITTER
            AsmEmitter emitter;
            emitter = new AsmEmitter();
            return emitter.Emit(asm);
        }
    }
}
