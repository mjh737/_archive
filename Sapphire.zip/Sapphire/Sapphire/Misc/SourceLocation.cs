﻿namespace Sapphire.Misc
{
    using System;

    public sealed class SourceLocation
    {
        public int StartLine { get; }
        public int StartColumn { get; }
        public int EndLine { get; }
        public int EndColumn { get; }

        public static SourceLocation Unknown { get; } = new(0, 0, 0, 0);

        public bool IsUnknown => ReferenceEquals(this, Unknown);

        public SourceLocation(int startLine, int startColumn, int endLine, int endColumn)
        {
            StartLine = startLine;
            StartColumn = startColumn;
            EndLine = endLine;
            EndColumn = endColumn;
        }

        public static SourceLocation Span(SourceLocation start, SourceLocation end) =>
            new(start.StartLine, start.StartColumn, end.EndLine, end.EndColumn);

        public override string ToString()
        {
            if (IsUnknown)
                return "<unknown location>";

            return StartLine == EndLine
                ? $"line {StartLine}, cols {StartColumn}-{EndColumn}"
                : $"lines {StartLine}-{EndLine}, cols {StartColumn}-{EndColumn}";
        }

        public static SourceLocation Synthetic() => new SourceLocation(0, 0, 0, 0);


    }

}
