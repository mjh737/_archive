﻿namespace Sapphire.Source
{
    using System;

    public static class Listings
    {
        public static string QuickTest = "QT";

        static string halfTab = "    ";
        public static string None = "None";

        public static string X0001 = "X0001";

        public static string L0001 = "L0001";
        public static string L0002 = "L0002";
        public static string L0003 = "L0003";
        public static string L0004 = "L0004";
        public static string L0005 = "L0005";
        public static string L0006 = "L0006";
        public static string L0007 = "L0007";
        public static string L0008 = "L0008";
        public static string L0009 = "L0009";
        public static string L0010 = "L0010";
        public static string L0011 = "L0011";
        public static string L0012 = "L0012";
        public static string L0013 = "L0013";
        public static string L0014 = "L0014";
        public static string L0015 = "L0015";
        public static string L0016 = "L0016";
        public static string L0017 = "L0017";
        public static string L0018 = "L0018";
        public static string L0019 = "L0019";
        public static string L0020 = "L0020";
        public static string L0021 = "L0021";
        public static string L0022 = "L0022";
        public static string L0023 = "L0023";
        public static string L0024 = "L0024";

        static string p1 = $"int main(void) {{\n{halfTab}";
        static string p2 = $"\n}}";
        static string p3 = $"int main(void) {{\n";

        private static Dictionary<string, string> listings = new Dictionary<string, string>()
        {
            { "QT", GetQuickTest() },

            { "X0001", p1 + "return 1ab;" + p2 },

            { "L0001", p1 + "return 0;" + p2 },
            { "L0002", p1 + "return 1;" + p2 },
            { "L0003", p1 + "return -1;" + p2 },
            { "L0004", p1 + "return 1+2;" + p2 },
            { "L0005", p1 + "return -(3+5);" + p2 },
            { "L0006", p1 + "return -(~2);" + p2 },
            { "L0007", p1 + "return 3*(4+2)/9;" + p2 },
            { "L0008", p1 + "return 1 > 2;" + p2 },
            { "L0009", p1 + "return 1 < 2;" + p2 },
            { "L0010", p1 + "return 5 >= 0;" + p2 },
            { "L0011", p1 + "int a; a = 7; return a;" + p2 },
            { "L0012", p1 + "int a; a = 7; int b = 12; return b-a;" + p2 },
            { "L0013", p1 + "int a = 6;" + p2 }, // No return value
            { "L0014", p3 + "if (3 > 1)\nreturn 5;\nelse\n8;" + p2 },
            { "L0015", p1 + "int a = 1; int b = 3; if (a)\nif(a>10)\nreturn a;\nelse return b-a;" + p2 },
            { "L0016", p1 + "int a = 17; if(a>100)\nreturn 0;\nelse if (a > 50)\nreturn 1;\nelse return 2;" + p2 },
            { "L0017", p1 + "int a = 6;" + p2 }, // No return value
            { "L0018", p1 + "int a = 7; int bvar = -1; if (a <= 3)\nreturn a;\nelse\nbvar=8;" + p2 },
            { "L0019", p1 + "int a = 7;\nreturn a <= 7 ? 1 : 2;" + p2 },
            { "L0020", p1 + "return 6 > 9 ? 1 : 0;" + p2 },
            { "L0021", p1 + "return 9 <= 10;" + p2 },
            { "L0022", p1 + "int x; { x = 3; } { return x; }" + p2 },
            { "L0023", p1 + "return 1 == 1;" + p2 },
            { "L0024", p1 + "int a = 3; { int b = a; int a = 4; return a; }" + p2 },


};

        private static string GetQuickTest()
        {
            return
                "int main(void) {return 5 >= 0;}\r\n";
        }

        //input = "return 5 >= 0;";
        //input = "return 5 >= 0 > 1;";
        //input = "return 5 >= 0 > 1 <= 0;";

        public static string Get(string name)
        {
            return listings[name];
        }

        //public static string P98 = p1 + "int a;\n\t{halfTab}a = 7;\n\t{halfTab}return a * 9;" + p2;
        //public static string P98t1 = p1 + "int a;\n\t{halfTab}int a;\n\t{halfTab}a = 7;\n\t{halfTab}return a * 9;" + p2;
        //public static string P98t1 = p1 + "int a;\n\t{halfTab}int b;\n\t{halfTab}a = 7;\n\t{halfTab}b = 9;\n\t{halfTab}return (a * b) + 37;" + p2;
        //public static string P98t1 = p1 + "int a = 9;\n\t{halfTab}int b;\n\t{halfTab}b = 9;\n\t{halfTab}return (a * b) + 37;" + p2;
    }
}
