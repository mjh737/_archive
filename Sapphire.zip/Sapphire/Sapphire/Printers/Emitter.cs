﻿namespace Sapphire.Printers
{
    using Sapphire.Assembler.Functions;
    using Sapphire.Assembler.Instructions;
    using Sapphire.Converter;
    using Sapphire.Misc;
    using Sapphire.XGenerator;
    using System;

    public class AsmEmitter : PrettyPrinter
    {
        private readonly HashSet<string> referencedLabels = new();
        private readonly HashSet<string> definedLabels = new();
        private const string FunctionEndLabel = "__func_end";
        private bool epilogueEmitted = false;

        public string Emit(AsmProgram program)
        {
            string output = PrintProgram(program);

            PrintToConsole(output, ConsoleColor.Blue, "ASM [EMITTER]");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("==========================================================");

            return output;
        }

        private string PrintProgram(AsmProgram program)
        {
            AddHeader(program.Name);

            foreach (var function in program.Functions)
            {
                EmitFunction(function);
            }

            AddFooter();

            return sb.ToString();
        }

        private void EmitFunction(AsmFunction ir)
        {
            var referencedLabels = CollectReferencedLabels(ir);
            var definedLabels = CollectDefinedLabels(ir);
            var emittedLabels = new HashSet<string>();

            foreach (var instr in ir.Instructions)
            {
                switch (instr)
                {
                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Label:
                        string label = i.Operand1.Identifier;
                        EmitLabel(new AsmLabel(label));
                        emittedLabels.Add(label);
                        if (label == FunctionEndLabel)
                        {
                            EmitEpilogue();
                            epilogueEmitted = true;
                        }
                        break;

                    case AsmComment comment:
                        EmitComment(comment);
                        break;

                    case AsmConditionalInstruction cond when cond.Mnemonic == AsmInstructions.Jmp:
                        ConvertJmp(cond);
                        break;

                    case AsmConditionalInstruction cond when cond.Mnemonic == AsmInstructions.JmpCC:
                        ConvertJmpCC(cond);
                        break;

                    case AsmConditionalInstruction cond when cond.Mnemonic == AsmInstructions.Set:
                        ConvertSetCC(cond);
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.AllocateStack:
                        ConvertAllocateStack(i);
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Mov:
                        ConvertMove(i);
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Neg:
                        ConvertNeg(i);
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Not:
                        ConvertNot(i);
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Add:
                        ConvertAdd(i);
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Sub:
                        ConvertSub(i);
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Mul:
                        ConvertMul(i);
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Cmp:
                        ConvertCmp(i);
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Cdq:
                        ConvertCdq(i);
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Idiv:
                        ConvertDiv(i);
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Jmp:
                        ConvertJmp(i);
                        break;

                    default:
                        // Suppress unhandled comment emission
                        break;
                }
            }

            EmitMissingLabels(referencedLabels, definedLabels.Union(emittedLabels).ToHashSet());

            // Clear for next function (optional if these are local)
            referencedLabels.Clear();
            definedLabels.Clear();
        }

        private HashSet<string> CollectReferencedLabels(AsmFunction ir)
        {
            var labels = new HashSet<string>();
            foreach (var instr in ir.Instructions)
            {
                if (instr is AsmConditionalInstruction j && j.Target != null)
                    labels.Add(j.Target);
                else if (instr is AsmConditionalInstruction cj && cj.Target != null)
                    labels.Add(cj.Target);
            }
            return labels;
        }

        private HashSet<string> CollectDefinedLabels(AsmFunction ir)
        {
            var labels = new HashSet<string>();
            foreach (var instr in ir.Instructions)
            {
                if (instr is AsmLabel label)
                    labels.Add(label.Label);
            }
            return labels;
        }

        private void EmitMissingLabels(HashSet<string> referenced, HashSet<string> defined)
        {
            foreach (var label in referenced.Except(defined))
            {
                EmitLabel(new AsmLabel(label));
                EmitComment(new AsmComment(
     $"placeholder for unresolved reference: {label}",
     SourceLocation.Synthetic(),
     Parser.SemanticTags.DebugHint
 ));

            }
        }




        private void EmitComment(AsmComment comment)
        {
            string prefix = comment.SemanticTag != null ? $"[{comment.SemanticTag}]" : "";
            sb.AppendLine($"; {prefix} {comment.Text}");
        }

        private void AddHeader(string programName)
        {
            sb.AppendLine("\t;");
            sb.AppendLine($"\t; ASM Program for Windows - {programName} - {DateTime.Today:yyyy-MM-dd} {DateTime.Now:HH:mm}");
            sb.AppendLine("\t;");
            sb.AppendLine();
            sb.AppendLine("\tsection .text");
            sb.AppendLine($"\tglobal main");
            sb.AppendLine();
            sb.AppendLine($"\tmain:");
            sb.AppendLine("\t    push   rbp");
            sb.AppendLine("\t    mov    rbp, rsp");
        }

        private void EmitLabel(AsmLabel instr)
        {
            definedLabels.Add(instr.Label);
            sb.AppendLine($"{instr}:");
        }


        private void ConvertAllocateStack(AsmInstruction instr) =>
            sb.AppendLine($"\t    sub    rsp, {instr.Operand1.Value}");

        private void ConvertCmp(AsmInstruction instr) =>
            sb.AppendLine($"\t    cmp    {instr.Operand2.ToAsmValue()}, {instr.Operand1.ToAsmValue()}");

        private void ConvertJmp(AsmInstruction instr) =>
            sb.AppendLine($"\t    jmp    {instr.Operand1.ToAsmValue()}");

        // Route conditional jumps to the conditional converter
        private void ConvertJmp(AsmConditionalInstruction instr)
        {
            if (instr.Mnemonic == AsmInstructions.JmpCC)
            {
                ConvertJmpCC(instr);
                return;
            }

            referencedLabels.Add(instr.Target);
            sb.AppendLine($"\t    jmp    {instr.Target}");
        }

        private void ConvertJmpCC(AsmConditionalInstruction instr)
        {
            referencedLabels.Add(instr.Target);

            string cc = instr.ConditionCode switch
            {
                AsmConditionCodes.E  => "je",
                AsmConditionCodes.NE => "jne",
                AsmConditionCodes.G  => "jg",
                AsmConditionCodes.GE => "jge",
                AsmConditionCodes.L  => "jl",
                AsmConditionCodes.LE => "jle",
                _ => "jmp"
            };

            // Pad 2-letter mnemonics to width 3 so operands align with 3-letter ones
            string padded = cc.PadRight(3);
            sb.AppendLine($"\t    {padded}    {instr.Target}");
        }

        private void ConvertSetCC(AsmConditionalInstruction instr)
        {
            referencedLabels.Add(instr.Target); // Track the label or symbolic target
            sb.AppendLine($"\t    {BuildOperator("set", instr.ConditionCode.ToString())}dword [rbp-{instr.Target}]");
        }


        private void ConvertNot(AsmInstruction instr) =>
            sb.AppendLine($"\t    not    {instr.Operand1.ToAsmValue()}");

        private void ConvertNeg(AsmInstruction instr) =>
            sb.AppendLine($"\t    neg    {instr.Operand1.ToAsmValue()}");

        private void ConvertMove(AsmInstruction instr) =>
            sb.AppendLine($"\t    mov    {instr.Operand2.ToAsmValue()}, {instr.Operand1.ToAsmValue()}");

        private void ConvertAdd(AsmInstruction instr) =>
            sb.AppendLine($"\t    add    {instr.Operand2.ToAsmValue()}, {instr.Operand1.ToAsmValue()}");

        private void ConvertSub(AsmInstruction instr) =>
            sb.AppendLine($"\t    sub    {instr.Operand2.ToAsmValue()}, {instr.Operand1.ToAsmValue()}");

        private void ConvertMul(AsmInstruction instr) =>
            sb.AppendLine($"\t    imul   {instr.Operand2.ToAsmValue()}, {instr.Operand1.ToAsmValue()}");

        private void ConvertCdq(AsmInstruction instr) =>
            sb.AppendLine($"\t    cdq");

        private void ConvertDiv(AsmInstruction instr) =>
            sb.AppendLine($"\t    idiv   {instr.Operand1.ToAsmValue()}");

        private void AddFooter()
        {
            if (!epilogueEmitted)
            {
                EmitEpilogue();
            }
        }

        private void EmitEpilogue()
        {
            sb.AppendLine("\t    mov    rsp, rbp");
            sb.AppendLine("\t    pop    rbp");
            sb.AppendLine("\t    ret");
        }

        private string BuildOperator(string prefix, string code)
        {
            string spaces = new string(' ', Math.Max(1, 4 - code.Length));
            return $"{prefix}{code.ToLower()}{spaces}";
        }
    }
}
