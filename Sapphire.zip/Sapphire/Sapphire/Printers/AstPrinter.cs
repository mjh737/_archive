﻿using Sapphire.Parser;

namespace Sapphire.Printers
{
    using Sapphire.Parser.Expressions;
    using Sapphire.Parser.Functions;
    using Sapphire.Parser.Statements;
    using System;
    using System.Text;

    public class AstPrinter : PrettyPrinter
    {
        public bool ShowSourceLocations { get; set; } = true;

        public string Print(AstProgram program)
        {
            sb.Clear();
            sb.AppendLine($"{Indent()}Program");
            IndentLevel++;

            foreach (var function in program.Functions)
                PrintFunction(function);

            IndentLevel--;
            string output = sb.ToString();

            PrintToConsole(output, ConsoleColor.Green, "AST TREE [PARSER]");
            return output;
        }

        private void PrintFunction(AstFunctionDeclaration function)
        {
            sb.AppendLine($"{Indent()}Function: {function.Name.OriginalName} @ {function.Location}");
            IndentLevel++;
            sb.AppendLine($"{Indent()}name = {function.Name.OriginalName}");
            sb.AppendLine($"{Indent()}body:");
            IndentLevel++;
            PrintBlockItems(function.Body.BlockItems);
            IndentLevel -= 2;
        }

        private void PrintBlockItems(List<AstBlockItem> blockItems)
        {
            foreach (var item in blockItems)
            {
                switch (item)
                {
                    case AstBlockItem.DeclarationItem d:
                        PrintDeclaration(d.D);
                        break;
                    case AstBlockItem.StatementItem s:
                        PrintStatement(s.S);
                        break;
                    default:
                        sb.AppendLine($"{Indent()}<UnknownBlockItem: {item.GetType().Name}>");
                        break;
                }
            }
        }

        private void PrintDeclaration(AstDeclaration decl)
        {
            sb.AppendLine($"{Indent()}Declaration: {decl.Identifier}");
            IndentLevel++;
            sb.AppendLine($"{Indent()}Location: {decl.Location}");

            if (decl.Initializer != null)
            {
                sb.AppendLine($"{Indent()}Value:");
                IndentLevel++;
                sb.AppendLine(PrintExpression(decl.Initializer).TrimEnd());
                IndentLevel--;
            }

            IndentLevel--;
        }


        private void PrintStatement(AstStatement stmt)
        {
            switch (stmt)
            {
                case AstReturnStatement r:
                    sb.AppendLine($"{Indent()}Return");
                    IndentLevel++;
                    sb.AppendLine(PrintExpression(r.Expression).TrimEnd());
                    IndentLevel--;
                    break;

                case AstExpressionStatement e:
                    sb.AppendLine($"{Indent()}Expr");
                    IndentLevel++;
                    sb.AppendLine(PrintExpression(e.Expression).TrimEnd());
                    IndentLevel--;
                    break;

                case AstBreakStatement b:
                    sb.AppendLine($"{Indent()}Break @ {b.Location}");
                    break;

                case AstContinueStatement c:
                    sb.AppendLine($"{Indent()}Continue @ {c.Location}");
                    break;

                case AstNullStatement n:
                    sb.AppendLine($"{Indent()}NullStatement @ {n.Location}");
                    break;

                case AstCompoundStatement c:
                    sb.AppendLine($"{Indent()}Compound");
                    IndentLevel++;
                    PrintBlockItems(c.Block.BlockItems);
                    IndentLevel--;
                    break;

                case AstDoWhileStatement d:
                    sb.AppendLine($"{Indent()}DoWhile");
                    IndentLevel++;
                    sb.AppendLine($"{Indent()}Body:");
                    IndentLevel++;
                    PrintStatement(d.Body);
                    IndentLevel--;
                    sb.AppendLine($"{Indent()}Cond:");
                    IndentLevel++;
                    sb.AppendLine(PrintExpression(d.Condition).TrimEnd());
                    IndentLevel -= 2;
                    break;

                case AstWhileStatement w:
                    sb.AppendLine($"{Indent()}While");
                    IndentLevel++;
                    sb.AppendLine($"{Indent()}Cond:");
                    IndentLevel++;
                    sb.AppendLine(PrintExpression(w.Condition).TrimEnd());
                    IndentLevel--;
                    sb.AppendLine($"{Indent()}BreakLabel: {w.BreakLabel?.UniqueName}");
                    sb.AppendLine($"{Indent()}ContinueLabel: {w.ContinueLabel?.UniqueName}");
                    sb.AppendLine($"{Indent()}Body:");
                    IndentLevel++;
                    PrintStatement(w.Body);
                    IndentLevel -= 2;
                    break;

                case AstIfStatement i:
                    sb.AppendLine($"{Indent()}If");
                    IndentLevel++;
                    sb.AppendLine($"{Indent()}Cond:");
                    IndentLevel++;
                    sb.AppendLine(PrintExpression(i.Condition).TrimEnd());
                    IndentLevel--;
                    sb.AppendLine($"{Indent()}Then:");
                    IndentLevel++;
                    PrintStatement(i.TrueBranch);
                    IndentLevel--;
                    if (i.FalseBranch != null)
                    {
                        sb.AppendLine($"{Indent()}Else:");
                        IndentLevel++;
                        PrintStatement(i.FalseBranch);
                        IndentLevel--;
                    }
                    IndentLevel--;
                    break;

                case AstForStatement f:
                    sb.AppendLine($"{Indent()}For");
                    IndentLevel++;

                    // Init
                    sb.AppendLine($"{Indent()}Init:");
                    IndentLevel++;
                    switch (f.Init)
                    {
                        case AstForInitDecl d:
                            sb.AppendLine($"{Indent()}Declaration: {d.Identifier}");
                            IndentLevel++;
                            sb.AppendLine($"{Indent()}Location: {d.Identifier.Location}");
                            if (d.Initializer != null)
                            {
                                sb.AppendLine($"{Indent()}Value:");
                                IndentLevel++;
                                sb.AppendLine(PrintExpression(d.Initializer).TrimEnd());
                                IndentLevel--;
                            }
                            IndentLevel--;
                            break;

                        case AstForInitExp e:
                            sb.AppendLine(PrintExpression(e.Expression).TrimEnd());
                            break;
                    }
                    IndentLevel--;

                    // Condition
                    sb.AppendLine($"{Indent()}Cond:");
                    IndentLevel++;
                    sb.AppendLine(f.Condition != null ? PrintExpression(f.Condition).TrimEnd() : $"{Indent()}<no condition>");
                    IndentLevel--;

                    // Post
                    sb.AppendLine($"{Indent()}Post:");
                    IndentLevel++;
                    sb.AppendLine(f.Post != null ? PrintExpression(f.Post).TrimEnd() : $"{Indent()}<none>");
                    IndentLevel--;

                    // Body
                    sb.AppendLine($"{Indent()}Body:");
                    IndentLevel++;
                    PrintStatement(f.Body);

                    IndentLevel -= 2;
                    break;

                default:
                    sb.AppendLine($"{Indent()}<UnknownStatement: {stmt.GetType().Name}>");
                    break;
            }
        }

        private string PrintExpression(AstExpression expr, bool compact = false)
        {
            string locationTag = ShowSourceLocations && expr.Location != null
        ? $" // {expr.Location}"
        : "";

            switch (expr)
            {
                case AstConstantExpression c:
                    return $"{Indent()}Constant({c.Value}){locationTag}";

                case AstVarExpression v:
                    return $"{Indent()}Var({v.Identifier}){locationTag}";

                case AstUnaryExpression u when compact:
                    return $"{Indent()}Unary({u.UnaryOperator}, {PrintExpression(u.Operand, true).Trim()}){locationTag}";

                case AstUnaryExpression u:
                    var sbUnary = new StringBuilder();
                    sbUnary.AppendLine($"{Indent()}Unary");
                    IndentLevel++;
                    sbUnary.AppendLine(PrintExpression(u.Operand).TrimEnd());
                    sbUnary.AppendLine($"{Indent()}{u.UnaryOperator}");
                    IndentLevel--;
                    sbUnary.Append($"{Indent()}");
                    return sbUnary.ToString();

                case AstBinaryExpression b:
                    var sbBinary = new StringBuilder();
                    sbBinary.AppendLine($"{Indent()}Binary");
                    IndentLevel++;
                    sbBinary.AppendLine(PrintExpression(b.Operand1).TrimEnd());
                    sbBinary.AppendLine($"{Indent()}{b.BinaryOperator}");
                    sbBinary.AppendLine(PrintExpression(b.Operand2).TrimEnd());
                    IndentLevel--;
                    sbBinary.Append($"{Indent()}");
                    return sbBinary.ToString();

                case AstTernaryExpression t:
                    var sbTernary = new StringBuilder();
                    sbTernary.AppendLine($"{Indent()}Ternary");
                    IndentLevel++;
                    sbTernary.AppendLine(PrintExpression(t.Condition).TrimEnd());
                    sbTernary.AppendLine(PrintExpression(t.TrueBranch).TrimEnd());
                    sbTernary.AppendLine(PrintExpression(t.FalseBranch).TrimEnd());
                    IndentLevel--;
                    sbTernary.Append($"{Indent()}");
                    return sbTernary.ToString();

                case AstAssignmentExpression a:
                    var sbAssign = new StringBuilder();
                    sbAssign.AppendLine($"{Indent()}Assignment");
                    IndentLevel++;
                    sbAssign.AppendLine(PrintExpression(a.Expression1).TrimEnd());
                    sbAssign.AppendLine(PrintExpression(a.Expression2).TrimEnd());
                    IndentLevel--;
                    sbAssign.Append($"{Indent()}");
                    return sbAssign.ToString();

                default:
                    return $"{Indent()}<UnknownExpr: {expr.GetType().Name}>{locationTag}";
            }
        }
    }
}
