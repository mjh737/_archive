﻿namespace Sapphire.Printers
{
    using System;
    using System.Text;

    public class PrettyPrinter
    {
        public StringBuilder sb;

        public PrettyPrinter()
        {
            sb = new StringBuilder();
        }

        public int IndentLevel = 2;
        public string Indent() => new string(' ', IndentLevel * 4);

        public void PrintToConsole(string output, ConsoleColor colour, string label)
        {
            Console.ForegroundColor = colour;

            Console.WriteLine("==========================================================");
            Console.WriteLine();
            Console.WriteLine($"\tPRINTING {label.ToUpper()}");
            Console.WriteLine();
            Console.WriteLine(output);
            Console.WriteLine();
            Console.WriteLine($"\tFINISHED PRINTING {label.ToUpper()}");
            Console.WriteLine();
            Console.ResetColor();
        }
    }
}
