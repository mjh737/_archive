﻿using Sapphire.Parser;

namespace Sapphire.Printers
{
    using Sapphire.Parser.Expressions;
    using Sapphire.Parser.Functions;
    using Sapphire.Parser.Statements;
    using System;
    using System.Text;

    public class ResolverPrinter : PrettyPrinter
    {
        private readonly StringBuilder sb = new();
        private int IndentLevel = 0;

        public bool ShowSourceLocations { get; set; } = true;

        private string Indent() => new string(' ', IndentLevel * 4);

        public string Print(AstProgram program)
        {
            sb.Clear();

            sb.AppendLine($"\t{Indent()}Program");
            IndentLevel++;

            foreach (var function in program.Functions)
            {
                PrintFunction(function);
            }

            IndentLevel--;

            string output = sb.ToString();
            PrintToConsole(output, ConsoleColor.Yellow, "AST TREE [RESOLVER]");
            return output;
        }

        private void PrintFunction(AstFunctionDeclaration function)
        {
            sb.AppendLine($"\t{Indent()}Function: {function.Name}");
            if (ShowSourceLocations)
                sb.AppendLine($"\t{Indent()}Location: {function.Location}");

            IndentLevel++;
            sb.AppendLine($"\t{Indent()}name={function.Name} @ {function.Location}");
            sb.AppendLine($"\t{Indent()}body:");
            IndentLevel++;

            sb.AppendLine($"\t{Indent()}AstBlock @ {function.Body.Location}");
            IndentLevel++;
            PrintBlockItems(function.Body.BlockItems);
            IndentLevel -= 2;
        }

        private void PrintBlockItems(List<AstBlockItem> blockItems)
        {
            foreach (var item in blockItems)
            {
                switch (item)
                {
                    case AstBlockItem.DeclarationItem d:
                        sb.AppendLine($"\t{Indent()}DeclarationItem");
                        IndentLevel++;
                        PrintDeclaration(d.D);
                        IndentLevel--;
                        break;

                    case AstBlockItem.StatementItem s:
                        sb.AppendLine($"\t{Indent()}StatementItem");
                        IndentLevel++;
                        PrintStatement(s.S);
                        IndentLevel--;
                        break;

                    default:
                        sb.AppendLine($"{Indent()}<UnknownBlockItem: {item.GetType().Name}>");
                        break;
                }
            }
        }

        private void PrintDeclaration(AstDeclaration decl)
        {
            sb.AppendLine($"{Indent()}Declaration: {decl.Identifier} // {decl.Location}");
            IndentLevel++;
            if (decl.Initializer != null)
                sb.AppendLine(PrintExpression(decl.Initializer));
            IndentLevel--;
        }

        private void PrintStatement(AstStatement stmt)
        {
            switch (stmt)
            {
                case AstReturnStatement r:
                    sb.AppendLine($"{Indent()}Return");
                    IndentLevel++;
                    sb.AppendLine(PrintExpression(r.Expression));
                    IndentLevel--;
                    break;

                case AstExpressionStatement e:
                    sb.AppendLine($"{Indent()}Expr");
                    IndentLevel++;
                    sb.AppendLine(PrintExpression(e.Expression));
                    IndentLevel--;
                    break;

                case AstBreakStatement b:
                    sb.AppendLine($"{Indent()}Break @ {b.Location}");
                    break;

                case AstContinueStatement c:
                    sb.AppendLine($"{Indent()}Continue @ {c.Location}");
                    break;

                case AstNullStatement n:
                    sb.AppendLine($"{Indent()}NullStatement @ {n.Location}");
                    break;

                case AstCompoundStatement c:
                    sb.AppendLine($"{Indent()}Compound");
                    IndentLevel++;
                    PrintBlockItems(c.Block.BlockItems);
                    IndentLevel--;
                    break;

                case AstDoWhileStatement d:
                    sb.AppendLine($"{Indent()}DoWhile");
                    IndentLevel++;
                    sb.AppendLine($"{Indent()}Body:");
                    IndentLevel++;
                    PrintStatement(d.Body);
                    IndentLevel--;
                    sb.AppendLine($"{Indent()}Cond:");
                    IndentLevel++;
                    sb.AppendLine(PrintExpression(d.Condition));
                    IndentLevel -= 2;
                    break;

                case AstWhileStatement w:
                    sb.AppendLine($"{Indent()}While");
                    IndentLevel++;
                    sb.AppendLine($"{Indent()}Cond:");
                    IndentLevel++;
                    sb.AppendLine(PrintExpression(w.Condition));
                    IndentLevel--;
                    sb.AppendLine($"{Indent()}BreakLabel: {w.BreakLabel?.UniqueName}");
                    sb.AppendLine($"{Indent()}ContinueLabel: {w.ContinueLabel?.UniqueName}");
                    sb.AppendLine($"{Indent()}Body:");
                    IndentLevel++;
                    PrintStatement(w.Body);
                    IndentLevel -= 2;
                    break;

                case AstIfStatement i:
                    sb.AppendLine($"{Indent()}If");
                    IndentLevel++;
                    sb.AppendLine($"{Indent()}Cond:");
                    IndentLevel++;
                    sb.AppendLine(PrintExpression(i.Condition));
                    IndentLevel--;
                    sb.AppendLine($"{Indent()}Then:");
                    IndentLevel++;
                    PrintStatement(i.TrueBranch);
                    IndentLevel--;
                    if (i.FalseBranch != null)
                    {
                        sb.AppendLine($"{Indent()}Else:");
                        IndentLevel++;
                        PrintStatement(i.FalseBranch);
                        IndentLevel--;
                    }
                    IndentLevel--;
                    break;

                case AstForStatement f:
                    sb.AppendLine($"{Indent()}For");
                    IndentLevel++;
                    sb.AppendLine($"{Indent()}Init:");
                    IndentLevel++;
                    switch (f.Init)
                    {
                        case AstForInitDecl d:
                            sb.AppendLine($"{Indent()}Declaration: {d.Identifier}" +
                                (d.Initializer != null ? $" = {PrintExpression(d.Initializer)}" : ""));
                            break;
                        case AstForInitExp e:
                            sb.AppendLine(PrintExpression(e.Expression));
                            break;
                    }
                    IndentLevel--;
                    sb.AppendLine($"{Indent()}Cond:");
                    IndentLevel++;
                    sb.AppendLine(PrintExpression(f.Condition));
                    IndentLevel--;
                    sb.AppendLine($"{Indent()}Post:");
                    IndentLevel++;
                    sb.AppendLine(f.Post != null ? PrintExpression(f.Post) : $"{Indent()}<none>");
                    IndentLevel--;
                    sb.AppendLine($"{Indent()}Body:");
                    IndentLevel++;
                    PrintStatement(f.Body);
                    IndentLevel -= 2;
                    break;

                default:
                    sb.AppendLine($"{Indent()}<UnknownStatement: {stmt.GetType().Name}>");
                    break;
            }
        }

        private string PrintExpression(AstExpression expr, bool compact = false)
        {
            string locationTag = ShowSourceLocations && expr != null && expr.Location != null
                ? $" // {expr.Location}"
                : "";

            if (expr == null)
                return $"{Indent()}<null expression>";

            switch (expr)
            {
                case AstConstantExpression c:
                    return $"{Indent()}Constant({c.Value}){locationTag}";

                case AstVarExpression v:
                    return $"{Indent()}Var({v.Identifier}){locationTag}";

                case AstUnaryExpression u when compact:
                    return $"{Indent()}Unary({u.UnaryOperator}, {PrintExpression(u.Operand, true).Trim()}){locationTag}";

                case AstUnaryExpression u:
                    var sbUnary = new StringBuilder();
                    sbUnary.AppendLine($"{Indent()}Unary");
                    IndentLevel++;
                    sbUnary.AppendLine(PrintExpression(u.Operand));
                    sbUnary.AppendLine($"{Indent()}{u.UnaryOperator}");
                    IndentLevel--;
                    return sbUnary.ToString();

                case AstBinaryExpression b:
                    var sbBinary = new StringBuilder();
                    sbBinary.AppendLine($"{Indent()}Binary");
                    IndentLevel++;
                    sbBinary.AppendLine(PrintExpression(b.Operand1));
                    sbBinary.AppendLine($"{Indent()}{b.BinaryOperator}");
                    sbBinary.AppendLine(PrintExpression(b.Operand2));
                    IndentLevel--;
                    return sbBinary.ToString();

                case AstTernaryExpression t:
                    var sbTernary = new StringBuilder();
                    sbTernary.AppendLine($"{Indent()}Ternary");
                    IndentLevel++;
                    sbTernary.AppendLine(PrintExpression(t.Condition));
                    sbTernary.AppendLine(PrintExpression(t.TrueBranch));
                    sbTernary.AppendLine(PrintExpression(t.FalseBranch));
                    IndentLevel--;
                    return sbTernary.ToString();

                case AstAssignmentExpression a:
                    var sbAssign = new StringBuilder();
                    sbAssign.AppendLine($"{Indent()}Assignment");
                    IndentLevel++;
                    sbAssign.AppendLine(PrintExpression(a.Expression1));
                    sbAssign.AppendLine(PrintExpression(a.Expression2));
                    IndentLevel--;
                    return sbAssign.ToString();

                default:
                    return $"{Indent()}<UnknownExpr: {expr.GetType().Name}>{locationTag}";
            }
        }

        //private void PrintToConsole(string text, ConsoleColor color, string title)
        //{
            
        //    var originalColor = Console.ForegroundColor;
        //    Console.ForegroundColor = color;
        //    Console.WriteLine($"\t=== {title} ===");
        //    Console.WriteLine();
        //    Console.WriteLine(text);
        //    Console.ForegroundColor = originalColor;
        //    Console.WriteLine();
        //}
    }
}