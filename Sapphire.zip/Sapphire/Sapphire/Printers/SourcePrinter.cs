﻿namespace Sapphire.Source
{
    using System;
    using System.Text;
    using Sapphire.Printers;

    public class SourcePrinter : PrettyPrinter
    {
        public void Print(string sourceCode, string name)
        {
            foreach (var line in sourceCode.Split(new[] { Environment.NewLine, "\n" }, StringSplitOptions.None))
            {
                sb.AppendLine($"{Indent()}{line}");
            }

            PrintToConsole(sb.ToString(), ConsoleColor.Yellow, $"Source Code {name} [C CODE]");
        }
    }
}
