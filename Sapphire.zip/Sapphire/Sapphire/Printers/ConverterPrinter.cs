﻿using Sapphire.Converter;

namespace Sapphire.Printers
{
    using Sapphire.Assembler.Functions;
    using Sapphire.Assembler.Instructions;
    using System.Collections.Generic;

    public class ConverterPrinter : PrettyPrinter
    {
        public void Print(AsmProgram program)
        {
            sb.AppendLine($"\t{program.ToString()}");
            PrintFunction(program.Functions[0]);
        }

        private void PrintFunction(AsmFunction function)
        {
            sb.AppendLine($"\t{function.ToString()}");
            sb.AppendLine();
            PrintInstructions(function.Instructions);
        }

        private string PrintInstructions(List<AsmInstruction> instructions)
        {
            foreach (var instr in instructions)
            {
                switch (instr)
                {
                    case AsmConditionalInstruction cj when cj.Mnemonic == AsmInstructions.JmpCC:
                        {
                            string cc = cj.ConditionCode switch
                            {
                                AsmConditionCodes.E  => "je",
                                AsmConditionCodes.NE => "jne",
                                AsmConditionCodes.G  => "jg",
                                AsmConditionCodes.GE => "jge",
                                AsmConditionCodes.L  => "jl",
                                AsmConditionCodes.LE => "jle",
                                _ => "jmp"
                            };
                            sb.AppendLine($"\t{cc.PadRight(8)}{cj.Target}");
                            break;
                        }

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Label:
                        sb.AppendLine();
                        sb.AppendLine($"{i.Operand1.Identifier}:");
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Jmp:
                        sb.AppendLine($"\t{"jmp".PadRight(8)}{i.Operand1.ToAsmValue()}");
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Cmp:
                        sb.AppendLine($"\t{"cmp".PadRight(8)}{i.Operand2.ToAsmValue()}  {i.Operand1.ToAsmValue()}");
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Mov:
                        sb.AppendLine($"\t{"mov".PadRight(8)}{i.Operand2.ToAsmValue()}  {i.Operand1.ToAsmValue()}");
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Add:
                        sb.AppendLine($"\t{"add".PadRight(8)}{i.Operand2.ToAsmValue()}  {i.Operand1.ToAsmValue()}");
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Sub:
                        sb.AppendLine($"\t{"sub".PadRight(8)}{i.Operand2.ToAsmValue()}  {i.Operand1.ToAsmValue()}");
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Mul:
                        sb.AppendLine($"\t{"imul".PadRight(8)}{i.Operand2.ToAsmValue()}  {i.Operand1.ToAsmValue()}");
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Cdq:
                        sb.AppendLine($"\tcdq");
                        break;

                    case AsmInstruction i when i.Mnemonic == AsmInstructions.Idiv:
                        sb.AppendLine($"\t{"idiv".PadRight(8)}{i.Operand1.ToAsmValue()}");
                        break;

                    case AsmInstruction i:
                        {
                            string m = i.Mnemonic.ToLower();
                            var op1 = i.Operand1.ToAsmValue();
                            var op2 = i.Operand2.ToAsmValue();
                            var op3 = i.Operand3.ToAsmValue();

                            // Build operand list ignoring empty operands
                            var parts = new List<string>();
                            if (!string.IsNullOrWhiteSpace(op1)) parts.Add(op1);
                            if (!string.IsNullOrWhiteSpace(op2)) parts.Add(op2);
                            if (!string.IsNullOrWhiteSpace(op3)) parts.Add(op3);

                            if (parts.Count > 0)
                                sb.AppendLine($"\t{m.PadRight(8)}{string.Join("  ", parts)}");
                            else
                                sb.AppendLine($"\t{m}");
                            break;
                        }

                    default:
                        // Fallback
                        sb.AppendLine(instr.ToString());
                        break;
                }
            }

            string output = sb.ToString();

            PrintToConsole(output, System.ConsoleColor.Gray, "IR WITH PSEUDO [CONVERTER]");

            return output;
        }
    }
}
