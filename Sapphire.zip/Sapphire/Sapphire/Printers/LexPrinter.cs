﻿using Sapphire.XLexer;

namespace Sapphire.Printers
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class LexPrinter : PrettyPrinter
    {
        public void Print(List<Token> tokens) 
        {

            //foreach (Token t in tokens)
            //{
            //    sb.AppendLine($"\tName: {t.Value,-10} Type: {t.Type}");
            //}

            for (int i = 0; i < tokens.Count; i++)
            {
                Console.WriteLine($"\t{i,2}: {tokens[i].Value,-10} {tokens[i].Type}");
            }


            PrintToConsole(sb.ToString(), ConsoleColor.Cyan, "Tokens [LEXER]");

        }
    }
}
