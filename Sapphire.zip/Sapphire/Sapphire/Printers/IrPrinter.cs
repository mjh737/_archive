﻿using Sapphire.XGenerator;

namespace Sapphire.Printers
{
    using System;
    using System.Collections.Generic;

    public class IrPrinter : PrettyPrinter
    {
        public void Print(IrProgram program)
        {
            sb.AppendLine($"\t{program.ToString()}");
            PrintFunction(program.Function);
        }

        private void PrintFunction(IrFunction function)
        {
            sb.AppendLine($"\t{function.ToString()}");
            sb.AppendLine();
            PrintInstructions(function.Instructions);
        }

        public string PrintInstructions(List<IrInstruction> instructions)
        {
            foreach (var instr in instructions)
            {
                sb.AppendLine($"\t{instr.ToString()}");
            }

            string output = sb.ToString();

            PrintToConsole(output, ConsoleColor.DarkYellow, "IR [GENERATOR]");

            return output;
        }
    }
}
