﻿namespace Sapphire
{
    using Sapphire.Exceptions;
    using Sapphire.Source;

    public class Compiler
    {
        static string listing = Listings.None;
        static string fileName = TestFiles.CH05_InvalidSemanticsMixedPrecedenceAssignment;

        static void Main(params string[] args)
        {
            if (args.Length == 0)
            {
                if (listing == Listings.None && fileName == TestFiles.None)
                    throw new CompilerException("No source specified");
                else if (listing != Listings.None && fileName != TestFiles.None)
                    throw new CompilerException("Listing and File sources cannot both be specified");

                Pipeline pipeline = new Pipeline();

                // LOAD FROM FILE
                if (fileName != TestFiles.None)
                    pipeline.ReadCompileAndDisplay(fileName);
                // LOAD LISTING
                else
                    pipeline.CompileAndDisplay(listing, Listings.Get(listing));
            }

            else
            {
                if (args[0].StartsWith("-"))
                    throw new CompilerException("No source file specified");
                else
                {
                    Pipeline pipeline = new Pipeline(args);
                    string file = args[0];
                    pipeline.CompileAndWrite(file);
                }
            }

            return;
        }
    }
}
