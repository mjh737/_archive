﻿namespace Sapphire.Resolver
{
    using Sapphire.Exceptions;
    using Sapphire.Misc;
    using System.Collections.Generic;

    public class VariableMap
    {
        private static int _counter = 1;
        private Stack<Dictionary<string, Identifier>> scopes = new();

        public Identifier Resolve(string name, SourceLocation location)
        {
            // Iterate from innermost to outermost so shadowing works
            foreach (var scope in scopes)
            {
                if (scope.TryGetValue(name, out var id))
                    return id;
            }
            throw new ResolverException($"Variable Not Declared: {name}", location);
        }

        public bool IsNameInCurrentScope(string name)
        {
            return scopes.Count > 0 && scopes.Peek().ContainsKey(name);
        }

        public Identifier Add(string originalName, SourceLocation location)
        {
            string uniqueName = $"{originalName}.{_counter++}";
            var id = new Identifier(originalName, uniqueName, location);
            scopes.Peek()[originalName] = id;

            Console.WriteLine($"\tAdded {id}");
            return id;
        }

        public void AddToCurrentScope(string name, string uniqueName, SourceLocation location)
        {
            if (scopes.Count == 0)
                EnterScope();

            var cur = scopes.Peek();
            if (cur.ContainsKey(name))
                throw new ResolverException($"Duplicate Variable Declaration {name} at line {location.StartLine}, cols {location.StartColumn}-{location.EndColumn}", location);

            cur[name] = new Identifier(name, uniqueName, location);
        }

        public void AddResolved(string originalName, Identifier resolvedIdentifier)
        {
            if (scopes.Count == 0)
                EnterScope();

            scopes.Peek()[originalName] = resolvedIdentifier;
        }

        public void EnterScope() => scopes.Push(new Dictionary<string, Identifier>());
        public void ExitScope() => scopes.Pop();

        public T WithNewScope<T>(Func<T> action)
        {
            EnterScope();
            try
            {
                return action();
            }
            finally
            {
                ExitScope();
            }
        }

        public void WithNewScope(Action action)
        {
            EnterScope();
            try
            {
                action();
            }
            finally
            {
                ExitScope();
            }
        }

        public static string MakeTemporaryVariable(string prefix) => $"{prefix}.{_counter++}";
        public static string MakeLabel(string name) => $"{name}_{_counter++}";
    }
}