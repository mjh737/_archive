﻿namespace Sapphire.Resolver
{
    using Sapphire.Misc;
    using System;
    using System.Collections.Generic;

    record ResolverContext
    {
        public Identifier? BreakTargetLabel { get; init; }
        public Identifier? ContinueTargetLabel { get; init; }
        private readonly Stack<ControlFlowTarget> _controlFlowTargets = new();
        public Dictionary<Identifier, SourceLocation> LabelDefinitions { get; private set; } = new();

        public ResolverContext WithBreakTarget(Identifier label) =>
            this with { BreakTargetLabel = label };

        public ResolverContext WithContinueTarget(Identifier label) =>
            this with { ContinueTargetLabel = label };

        public ResolverContext WithLabel(Identifier label, SourceLocation location)
        {
            var newContext = new ResolverContext
            {
                BreakTargetLabel = this.BreakTargetLabel,
                ContinueTargetLabel = this.ContinueTargetLabel,
                LabelDefinitions = new Dictionary<Identifier, SourceLocation>(this.LabelDefinitions)
            };
            newContext.LabelDefinitions[label] = location;
            return newContext;
        }

        public bool IsValidContinueTarget(Identifier label)
        {
            return _controlFlowTargets.Any(t => t.Label.Equals(label) && t.IsLoop);
        }

    }
}
