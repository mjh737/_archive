﻿namespace Sapphire.Resolver
{
    using Sapphire.Misc;

    class LabelGenerator
    {
        private int _counter = 0;

        public string Generate(string prefix, SourceLocation location)
        {
            int id = Interlocked.Increment(ref _counter);
            return $"{prefix}_{location.StartLine}_{location.StartColumn}_{id}";
        }
    }
}
