﻿namespace Sapphire.Resolver
{
    using Sapphire.Misc;
    using Sapphire.XGenerator;
    using Sapphire.XLexer;

    public sealed record Identifier(string OriginalName, string UniqueName, SourceLocation Location) : IrVal
    {
        public override string ToString() =>
            OriginalName == UniqueName
                ? $"{UniqueName} at {Location}"
                : $"{OriginalName} -> {UniqueName} at {Location}";

        public static Identifier FromToken(Token token) =>
    new(token.Value, token.Value, token.Location);

    }
}
