﻿namespace Sapphire.Resolver
{
    using Sapphire.Misc;
    using Sapphire.Exceptions;
    using Sapphire.Parser;
    using Sapphire.Parser.BlockItems;
    using Sapphire.Parser.Expressions;
    using Sapphire.Parser.Functions;
    using Sapphire.Parser.Statements;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class VariableResolver
    {
        private readonly LabelGenerator _labelGen = new();

        private string GenerateUniqueLabel(string prefix, SourceLocation location) =>
            _labelGen.Generate(prefix, location);

        public AstProgram Resolve(AstProgram prog)
        {
            AstProgram program = new AstProgram(prog.Name, ResolveFunction(prog.Functions[0]));
            Console.WriteLine();
            return program;
        }

        private AstFunctionDeclaration ResolveFunction(AstFunctionDeclaration function)
        {
            VariableMap variableMap = new VariableMap();
            ResolverContext context = new ResolverContext();

            AstBlock body = variableMap.WithNewScope(() =>
                ResolveBlock(function.Body, variableMap, context)
            );

            return new AstFunctionDeclaration(function.Name, body, body.Location);
        }

        // NEW: pre-bind declarations in a block so name lookups prefer the innermost scope
        private void PreBindDeclarations(AstBlock block, VariableMap map)
        {
            foreach (var declItem in block.BlockItems.OfType<AstBlockItem.DeclarationItem>())
            {
                string originalName = declItem.D.Identifier.OriginalName;

                // Always pre-bind; AddToCurrentScope will throw on duplicates in this scope
                string uniqueName = VariableMap.MakeTemporaryVariable(originalName);
                // Use identifier location for accurate duplicate error positions
                map.AddToCurrentScope(originalName, uniqueName, declItem.D.Identifier.Location);
            }
        }

        private AstBlock ResolveBlock(AstBlock block, VariableMap map, ResolverContext context)
        {
            List<AstBlockItem> blockItems = new List<AstBlockItem>();

            // 1) Pre-bind all declarations of this block in the current scope
            PreBindDeclarations(block, map);

            // 2) Resolve each item using the pre-bound identifiers
            foreach (AstBlockItem blockItem in block.BlockItems)
            {
                Console.WriteLine($"\tBlockItem {blockItem}");
                Console.WriteLine($"\tType: {blockItem.GetType().FullName}");
                Console.WriteLine($"\tIs DeclarationItem? {blockItem is AstBlockItem.DeclarationItem}");
                Console.WriteLine($"\tIs StatementItem? {blockItem is AstBlockItem.StatementItem}");

                if (blockItem is AstBlockItem.DeclarationItem d)
                    blockItems.Add(ResolveDeclaration(d.D, map));
                else if (blockItem is AstBlockItem.StatementItem s)
                    blockItems.Add(ResolveStatement(s.S, map, context));
                else
                    throw new ResolverException("Unknown Block Type", block.Location);
            }

            return new AstBlock(blockItems, block.Location);
        }

        private AstBlockItem ResolveStatement(AstStatement statement, VariableMap map, ResolverContext context)
        {
            return statement switch
            {
                AstReturnStatement ret => AstBlockItem.FromStatement(new AstReturnStatement(ResolveExpression(ret.Expression, map, allowAssignmentInTernaryBranches: true), statement.Location)),
                AstExpressionStatement expr => AstBlockItem.FromStatement(new AstExpressionStatement(ResolveExpression(expr.Expression, map, allowAssignmentInTernaryBranches: true), statement.Location)),
                AstCompoundStatement comp => ResolveCompoundStatement(comp.Block, map, context),
                AstNullStatement => AstBlockItem.FromStatement(new AstNullStatement(statement.Location)),
                AstIfStatement ifStmt => ResolveIfStatement(ifStmt, map, context),
                AstWhileStatement whileStmt => ResolveWhileStatement(whileStmt, map, context),
                AstDoWhileStatement doStmt => ResolveDoWhileStatement(doStmt, map, context),
                AstForStatement forStmt => ResolveForStatement(forStmt, map, context),
                AstBreakStatement breakStmt => AstBlockItem.FromStatement(ResolveBreak(breakStmt, context)),
                AstContinueStatement continueStmt => AstBlockItem.FromStatement(ResolveContinue(continueStmt, context)),
                _ => throw new ResolverException("Unrecognised Statement Type", statement.Location)
            };
        }

        private AstStatement ResolveBreak(AstBreakStatement breakStmt, ResolverContext context)
        {
            if (context.BreakTargetLabel is null)
                throw new ResolverException("'break' not within loop or switch", breakStmt.Location);

            return new AstBreakStatement(context.BreakTargetLabel, breakStmt.Location);
        }

        private AstStatement ResolveContinue(AstContinueStatement continueStmt, ResolverContext context)
        {
            Identifier? label = continueStmt.Label;

            if (label is null)
            {
                if (context.ContinueTargetLabel is null)
                    throw new ResolverException("'continue' not within loop or switch", continueStmt.Location);

                label = context.ContinueTargetLabel;
            }
            else
            {
                if (!context.IsValidContinueTarget(label))
                    throw new ResolverException($"Unknown continue label '{label.OriginalName}'", continueStmt.Location);
            }

            return new AstContinueStatement(label, continueStmt.Location);
        }

        private AstBlockItem ResolveCompoundStatement(AstBlock block, VariableMap map, ResolverContext context)
        {
            map.EnterScope();

            // Pre-bind happens inside ResolveBlock for this scope; avoid double-binding here
            var resolvedBlock = ResolveBlock(block, map, context);

            map.ExitScope();

            return AstBlockItem.FromStatement(new AstCompoundStatement(resolvedBlock, block.Location));
        }

        private AstBlockItem ResolveIfStatement(AstIfStatement ifStmt, VariableMap map, ResolverContext context)
        {
            AstExpression i = ResolveExpression(ifStmt.Condition, map);

            AstBlockItem t = ResolveStatement(ifStmt.TrueBranch, map, context);
            AstBlockItem? e = ifStmt.FalseBranch == null ? null : ResolveStatement(ifStmt.FalseBranch, map, context);

            AstStatement trueBranch = t is AstBlockItem.StatementItem tsi
                ? tsi.S
                : throw new ResolverException("True branch must be a StatementItem", ifStmt.Location);

            AstStatement? falseBranch = ifStmt.FalseBranch == null
                ? null
                : e is AstBlockItem.StatementItem esi
                    ? esi.S
                    : throw new ResolverException("False branch must be a StatementItem", ifStmt.Location);

            var newIfStmt = new AstIfStatement(i, trueBranch, ifStmt.Location, falseBranch);
            return AstBlockItem.FromStatement(newIfStmt);
        }

        private AstBlockItem ResolveWhileStatement(AstWhileStatement whileStmt, VariableMap map, ResolverContext context)
        {
            var breakLabel = new Identifier("break", GenerateUniqueLabel("break", whileStmt.Location), whileStmt.Location);
            var continueLabel = new Identifier("continue", GenerateUniqueLabel("continue", whileStmt.Location), whileStmt.Location);

            var loopContext = context with
            {
                BreakTargetLabel = breakLabel,
                ContinueTargetLabel = continueLabel
            };

            var resolvedCond = ResolveExpression(whileStmt.Condition, map);
            var bodyItem = ResolveStatement(whileStmt.Body, map, loopContext);

            if (bodyItem is AstBlockItem.StatementItem stmtItem)
            {
                var resolvedBody = stmtItem.S;
                var resolved = new AstWhileStatement(resolvedCond, resolvedBody, breakLabel, continueLabel, whileStmt.Location);
                return AstBlockItem.FromStatement(resolved);
            }
            else
            {
                throw new ResolverException("Loop body must be a statement", whileStmt.Body.Location);
            }
        }

        private AstBlockItem ResolveDoWhileStatement(AstDoWhileStatement doStmt, VariableMap map, ResolverContext context)
        {
            var breakLabel = new Identifier("break", GenerateUniqueLabel("break", doStmt.Location), doStmt.Location);
            var continueLabel = new Identifier("continue", GenerateUniqueLabel("continue", doStmt.Location), doStmt.Location);

            var loopContext = context with
            {
                BreakTargetLabel = breakLabel,
                ContinueTargetLabel = continueLabel
            };

            var bodyItem = ResolveStatement(doStmt.Body, map, loopContext);

            if (bodyItem is not AstBlockItem.StatementItem stmtItem)
                throw new ResolverException("do-while body must be a statement", doStmt.Body.Location);

            var resolvedBody = stmtItem.S;
            var resolvedCond = ResolveExpression(doStmt.Condition, map);

            var resolved = new AstDoWhileStatement(resolvedBody, resolvedCond, breakLabel, continueLabel, doStmt.Location);
            return AstBlockItem.FromStatement(resolved);
        }

        private AstBlockItem ResolveForStatement(AstForStatement forStmt, VariableMap map, ResolverContext context)
        {
            Identifier loopLabel = forStmt.Identifier is not null
                ? new Identifier(OriginalName: forStmt.Identifier.OriginalName, UniqueName: forStmt.Identifier.UniqueName, Location: forStmt.Location)
                : new Identifier(OriginalName: "loop", UniqueName: GenerateUniqueLabel("loop", forStmt.Location), Location: forStmt.Location);

            map.EnterScope(); // loop scope

            // Resolve init first so the loop-scoped variable is in scope
            AstForInit? init = ResolveForInit(forStmt.Init, map);

            // Resolve condition and post in the same scope (will bind to loop 'i')
            AstExpression? cond = forStmt.Condition is not null ? ResolveExpression(forStmt.Condition, map) : null;
            AstExpression? post = forStmt.Post is not null ? ResolveExpression(forStmt.Post, map) : null;

            // Loop labels for break/continue
            var loopContext = context with
            {
                BreakTargetLabel = loopLabel,
                ContinueTargetLabel = loopLabel
            };

            AstBlockItem b = ResolveStatement(forStmt.Body, map, loopContext);

            AstStatement body = b is AstBlockItem.StatementItem bsi
                ? bsi.S
                : throw new ResolverException("Body must be a StatementItem", forStmt.Location);

            map.ExitScope();

            var newForStmt = new AstForStatement(init, cond, post, body, loopLabel, forStmt.Location);
            return AstBlockItem.FromStatement(newForStmt);
        }

        private AstForInit? ResolveForInit(AstForInit? init, VariableMap map)
        {
            if (init is null || init is AstForInitNone)
                return null;

            return init switch
            {
                AstForInitDecl decl => ResolveForInitDecl(decl, map),
                AstForInitExp exp => ResolveForInitExpr(exp, map),
                _ => throw new ResolverException(
                    $"Unknown for-init type: {init.GetType().Name}",
                    (init as ILocatable)?.Location ?? SourceLocation.Unknown)
            };
        }

        private AstForInitDecl ResolveForInitDecl(AstForInitDecl decl, VariableMap map)
        {
            // Bind the loop variable in the loop scope
            var bound = map.Add(decl.Identifier.OriginalName, decl.Initializer?.Location ?? decl.Identifier.Location);

            // Resolve initializer in the loop scope
            AstExpression? resolvedInit = decl.Initializer is not null
                ? ResolveExpression(decl.Initializer, map, allowAssignmentInTernaryBranches: true)
                : null;

            return new AstForInitDecl(bound, resolvedInit);
        }

        private AstForInitExp? ResolveForInitExpr(AstForInitExp? expr, VariableMap map)
        {
            if (expr is null) return null;

            return expr switch
            {
                AstForInitExp exp => new AstForInitExp(ResolveExpression(exp.Expression, map, allowAssignmentInTernaryBranches: true)),
                _ => throw new ResolverException(
                    $"Unknown for-post expression type: {expr.GetType().Name}",
                    (expr as ILocatable)?.Location ?? SourceLocation.Unknown)
            };
        }

        private AstBlockItem ResolveDeclaration(AstDeclaration declaration, VariableMap map)
        {
            string originalName = declaration.Identifier.OriginalName;

            // If pre-bound in this scope, reuse its unique name; otherwise create a new one
            string uniqueName;
            if (map.IsNameInCurrentScope(originalName))
            {
                Identifier? current = map.Resolve(originalName, declaration.Location)
                    ?? throw new ResolverException($"Failed to resolve pre-bound name '{originalName}'", declaration.Location);
                uniqueName = current.UniqueName;
            }
            else
            {
                uniqueName = VariableMap.MakeTemporaryVariable(originalName);
                // Use identifier location for accurate duplicate error positions
                map.AddToCurrentScope(originalName, uniqueName, declaration.Identifier.Location);
            }

            AstExpression? resolvedInitializer = declaration.Initializer is not null
                ? ResolveExpression(declaration.Initializer, map, allowAssignmentInTernaryBranches: true)
                : null;

            var resolvedIdentifier = new Identifier(declaration.Identifier.OriginalName, uniqueName, declaration.Identifier.Location);
            var newDecl = new AstDeclaration(resolvedIdentifier, declaration.Location, resolvedInitializer);

            return AstBlockItem.FromDeclaration(newDecl);
        }

        // Overload with context flag to control ternary-branch assignment allowance
        private AstExpression ResolveExpression(AstExpression expression, VariableMap map, bool allowAssignmentInTernaryBranches)
        {
            switch (expression)
            {
                case AstAssignmentExpression ass:
                    if (ass.Expression1 is not AstVarExpression assExpr)
                        throw new ResolverException("Invalid LValue", expression.Location);

                    Console.WriteLine($"\tResolving assignment: {assExpr.Identifier.OriginalName} = ...");

                    return new AstAssignmentExpression(
                        ResolveExpression(assExpr, map, allowAssignmentInTernaryBranches),
                        ResolveExpression(ass.Expression2, map, allowAssignmentInTernaryBranches: true),
                        ass.Location
                    );

                case AstVarExpression varExpr:
                    Console.WriteLine($"\tResolving Var: {varExpr.Identifier}");

                    Identifier? resolvedId = map.Resolve(varExpr.Identifier.OriginalName, varExpr.Location);

                    if (resolvedId is null)
                        throw new ResolverException($"Undeclared variable: {varExpr.Identifier.OriginalName}", varExpr.Location);

                    return new AstVarExpression(resolvedId, varExpr.Location);

                case AstUnaryExpression un:
                    return new AstUnaryExpression(un.UnaryOperator, ResolveExpression(un.Operand, map, allowAssignmentInTernaryBranches), un.Location);

                case AstBinaryExpression bin:
                {
                    var lhs = ResolveExpression(bin.Operand1, map, allowAssignmentInTernaryBranches);
                    var rhs = ResolveExpression(bin.Operand2, map, allowAssignmentInTernaryBranches);

                    bool isComparison =
                        bin.BinaryOperator == AstBinaryOperators.EqualEqual ||
                        bin.BinaryOperator == AstBinaryOperators.NotEqual ||
                        bin.BinaryOperator == AstBinaryOperators.LessThan ||
                        bin.BinaryOperator == AstBinaryOperators.LessOrEqualTo ||
                        bin.BinaryOperator == AstBinaryOperators.GreaterThan ||
                        bin.BinaryOperator == AstBinaryOperators.GreaterOrEqualTo;

                    bool isArithmetic =
                        bin.BinaryOperator == AstBinaryOperators.Add ||
                        bin.BinaryOperator == AstBinaryOperators.Subtract ||
                        bin.BinaryOperator == AstBinaryOperators.Multiply ||
                        bin.BinaryOperator == AstBinaryOperators.Divide ||
                        bin.BinaryOperator == AstBinaryOperators.Modulo;

                    if ((isComparison || isArithmetic) && (lhs is AstAssignmentExpression || rhs is AstAssignmentExpression))
                        throw new ResolverException("Invalid LValue", bin.Location);

                    return new AstBinaryExpression(bin.BinaryOperator, lhs, rhs, bin.Location);
                }

                case AstTernaryExpression tern:
                {
                    var resolvedCond = ResolveExpression(tern.Condition, map, allowAssignmentInTernaryBranches: false);
                    var resolvedTrue = ResolveExpression(tern.TrueBranch, map, allowAssignmentInTernaryBranches);
                    var resolvedFalse = ResolveExpression(tern.FalseBranch, map, allowAssignmentInTernaryBranches);

                    if (!allowAssignmentInTernaryBranches &&
                        (resolvedTrue is AstAssignmentExpression || resolvedFalse is AstAssignmentExpression))
                    {
                        throw new ResolverException("Invalid LValue", tern.Location);
                    }

                    return new AstTernaryExpression(resolvedCond, resolvedTrue, resolvedFalse, tern.Location);
                }

                case AstConstantExpression con:
                    Console.WriteLine($"\tResolving Con: {con.Value}");
                    return new AstConstantExpression(con.Value, con.Location);

                default:
                    throw new ResolverException($"Unresolvable Expression Type {expression}", expression.Location);
            }
        }

        // Backward-compatible entry point
        private AstExpression ResolveExpression(AstExpression expression, VariableMap map)
            => ResolveExpression(expression, map, allowAssignmentInTernaryBranches: false);
    }
}
