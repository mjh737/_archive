﻿namespace Sapphire.Resolver
{
    public record ControlFlowTarget(Identifier Label, bool IsLoop, bool IsSwitch);
}
