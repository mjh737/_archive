﻿namespace Sapphire.Replacer
{
    using Sapphire.Assembler; // for AsmProgram
    using Sapphire.Assembler.Functions;
    using Sapphire.Assembler.Instructions;
    using Sapphire.Assembler.Operands;
    using Sapphire.Converter;
    using System.Collections.Generic;
    using System.Linq;

    public class PseudoReplacer
    {
        private readonly Dictionary<string, int> stackOffsetMap = new();
        private readonly LabelAllocator labelAllocator = new();
        private readonly HashSet<string> usedLabels = new();
        private int nextOffset = 0;

        public int StackOffset => nextOffset;

        public AsmProgram Run(AsmProgram prog)
        {
            var updatedFunctions = prog.Functions.Select(UpdateFunction).ToList();
            return new AsmProgram(prog.Name, updatedFunctions);
        }

        private AsmFunction UpdateFunction(AsmFunction function)
        {
            var updatedInstructions = UpdateInstructions(function.Instructions);
            // Labels are now sanitized in-place; no separate insertion pass
            return new AsmFunction(function.Name, updatedInstructions, function.Location);
        }

        private List<AsmInstruction> UpdateInstructions(List<AsmInstruction> instructions)
        {
            var newInstructions = new List<AsmInstruction>();

            foreach (var instruction in instructions)
            {
                // Sanitize operands (pseudos to stack)
                var op1 = ReplaceOperand(instruction.Operand1);
                var op2 = ReplaceOperand(instruction.Operand2);
                var op3 = ReplaceOperand(instruction.Operand3);

                AsmInstruction newInstr;

                if (instruction is AsmConditionalInstruction condJump)
                {
                    // Normalize conditional jump target label
                    var sanitizedTarget = labelAllocator.GetLabel(condJump.Target);
                    usedLabels.Add(sanitizedTarget);

                    var conditionOperand = ReplaceOperand(condJump.Operand1);

                    newInstr = new AsmConditionalInstruction(
                        condJump.Mnemonic,
                        condJump.ConditionCode,
                        conditionOperand,
                        sanitizedTarget
                    );
                }
                else if (instruction.Mnemonic == AsmInstructions.Jmp && op1 is { OpType: AsmOperands.Label })
                {
                    // Normalize unconditional jump target label
                    string sanitized = labelAllocator.GetLabel(op1.Identifier);
                    newInstr = new AsmInstruction(AsmInstructions.Jmp, new AsmOperand(AsmOperands.Label, sanitized));
                }
                else if (instruction.Mnemonic == AsmInstructions.Label && op1 is { OpType: AsmOperands.Label })
                {
                    // Normalize label definition to the same sanitized name used by jumps
                    string sanitized = labelAllocator.GetLabel(op1.Identifier);
                    newInstr = new AsmInstruction(AsmInstructions.Label, new AsmOperand(AsmOperands.Label, sanitized));
                    usedLabels.Add(sanitized);
                }
                else
                {
                    newInstr = new AsmInstruction(instruction.Mnemonic, op1, op2, op3);
                }

                newInstructions.Add(newInstr);
            }

            return newInstructions;
        }

        private AsmOperand ReplaceOperand(AsmOperand operand)
        {
            if (operand == null || operand.OpType != AsmOperands.Pseudo)
                return operand;

            if (!stackOffsetMap.TryGetValue(operand.Identifier, out var offset))
            {
                nextOffset += 4;
                offset = nextOffset;
                stackOffsetMap[operand.Identifier] = offset;

            }

            return new AsmOperand(AsmOperands.Stack, offset);
        }
    }
}
