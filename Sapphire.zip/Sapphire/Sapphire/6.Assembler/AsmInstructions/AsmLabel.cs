﻿namespace Sapphire.Assembler.Instructions
{
    public record AsmLabel : AsmInstruction
    {
        public string Label { get; }

        public AsmLabel(string label) : base("label")
        {
            Label = label;
        }

        public override string ToString()
        {
            return $"{Label}";
        }
    }
}
