﻿namespace Sapphire.Assembler.Instructions
{
    using Sapphire.Assembler.Operands;

    public record AsmConditionalInstruction : AsmInstruction
    {
        public string Target { get; set; }
        public AsmConditionCodes ConditionCode { get; protected set; }

        public AsmConditionalInstruction(string mnemonic, string target) : base(mnemonic)
        {
            Mnemonic = mnemonic;
            Target = target;
        }

        public AsmConditionalInstruction(string mnemonic, AsmConditionCodes condCode) : base(mnemonic)
        {
            Mnemonic = mnemonic;
            ConditionCode = condCode;
        }

        public AsmConditionalInstruction(string mnemonic, AsmConditionCodes condCode, AsmOperand destination) : base(mnemonic, destination)
        {
            Mnemonic = mnemonic;
            ConditionCode = condCode;
        }

        public AsmConditionalInstruction(string mnemonic, AsmConditionCodes condCode, string target) : base(mnemonic)
        {
            Mnemonic = mnemonic;
            ConditionCode = condCode;
            Target = target;
        }

        public AsmConditionalInstruction(string mnemonic, AsmConditionCodes condCode, AsmOperand conditionOperand, string target)
    : base(mnemonic, conditionOperand)
        {
            Mnemonic = mnemonic;
            ConditionCode = condCode;
            Target = target;
        }


        public override string ToString()
        {
            string suffix = ConditionCode switch
            {
                AsmConditionCodes.E => "e",
                AsmConditionCodes.NE => "ne",
                AsmConditionCodes.G => "g",
                AsmConditionCodes.GE => "ge",
                AsmConditionCodes.L => "l",
                AsmConditionCodes.LE => "le",
                AsmConditionCodes.Z => "z",
                AsmConditionCodes.NZ => "nz",
                _ => "??"
            };

            string conditionSymbol = ConditionCode switch
            {
                AsmConditionCodes.E => "==",
                AsmConditionCodes.NE => "!=",
                AsmConditionCodes.G => ">",
                AsmConditionCodes.GE => ">=",
                AsmConditionCodes.L => "<",
                AsmConditionCodes.LE => "<=",
                AsmConditionCodes.Z => "== 0",
                AsmConditionCodes.NZ => "!= 0",
                _ => $"?{ConditionCode}"
            };

            string fullMnemonic = $"{Mnemonic}{suffix}";
            string spacing = new string(' ', Math.Max(1, 8 - fullMnemonic.Length));
            return $"\t{fullMnemonic}{spacing}{Target}"; //    ; if {base.Operand1} {conditionSymbol}";
        }

    }
}
