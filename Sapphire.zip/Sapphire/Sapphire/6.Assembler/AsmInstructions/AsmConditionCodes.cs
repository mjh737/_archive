﻿namespace Sapphire.Assembler.Instructions
{
    using System.ComponentModel;

    public enum AsmConditionCodes
    {
        [Description("Always true")]
        E,
        [Description("Always false")]
        NE,
        [Description("Greater than")]
        G,
        [Description("Greater than or equal to")]
        GE,
        [Description("Less than")]
        L,
        [Description("Less than or equal to")]
        LE,
        [Description("Equal to zero")]
        Z,
        [Description("Not equal to zero")]
        NZ
    }
}
