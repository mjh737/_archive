﻿namespace Sapphire.Assembler.Instructions
{
    using Sapphire.Assembler.Operands;

    public record class AsmInstruction(
            string Mnemonic,
            AsmOperand Operand1,
            AsmOperand Operand2,
            AsmOperand Operand3)
    {
        public AsmInstruction(string mnemonic)
            : this(mnemonic, new AsmOperand(), new AsmOperand(), new AsmOperand()) { }

        public AsmInstruction(string mnemonic, AsmOperand destination)
            : this(mnemonic, destination, new AsmOperand(), new AsmOperand()) { }

        public AsmInstruction(string mnemonic, params AsmOperand[] operands)
            : this(
                mnemonic,
                operands.Length > 0 ? operands[0] : new AsmOperand(),
                operands.Length > 1 ? operands[1] : new AsmOperand(),
                operands.Length > 2 ? operands[2] : new AsmOperand())
        { }

        public override string ToString()
        {
            if (Mnemonic == AsmInstructions.Label &&
                Operand1?.OpType == AsmOperands.Label &&
                !string.IsNullOrWhiteSpace(Operand1.Identifier))
            {
                return $"{Operand1.Identifier}:";
            }

            var parts = new List<string> { Mnemonic };

            if (Operand2?.OpType != AsmOperands.None)
                parts.Add(Operand2.ToAsmString());

            if (Operand1?.OpType != AsmOperands.None)
                parts.Add(Operand1.ToAsmString());

            if (Operand3?.OpType != AsmOperands.None)
                parts.Add(Operand3.ToAsmString());

            return "\t" + string.Join("\t", parts);
        }

        public static AsmInstruction Jmp(string targetLabel) =>
            new AsmInstruction(
                AsmInstructions.Jmp,
                new AsmOperand(AsmOperands.Label, targetLabel),
                AsmOperand.None(),
                AsmOperand.None());
    }
}