﻿namespace Sapphire.Assembler.Instructions
{
    using Sapphire.Assembler.Operands;
    using Sapphire.Misc;
    using Sapphire.Parser;

    public record class AsmComment(
    string Text,
    SourceLocation Location,
    SemanticTags? SemanticTag = null
) : AsmInstruction(
    AsmInstructions.Comment,
    new AsmOperand(AsmOperands.Comment, Text),
    AsmOperand.None(),
    AsmOperand.None()
)
    {
        public override string ToString()
        {
            var tag = SemanticTag != null ? $"[{SemanticTag}] " : "";
            return $"\t// {tag}{Text}";
        }
    }

}
