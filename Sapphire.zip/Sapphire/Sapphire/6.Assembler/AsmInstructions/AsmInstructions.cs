﻿namespace Sapphire.Assembler.Instructions
{
    public static class AsmInstructions
    {
        public const string Cdq = "Cdq";
        public const string Idiv = "Idiv";
        public const string Mov = "Mov";
        public const string Ret = "Ret";
        public const string Not = "Not";
        public const string Neg = "Neg";

        public const string AllocateStack = "AllocateStack";

        public const string Mul = "Mul";
        public const string Add = "Add";
        public const string Sub = "Sub";

        public const string Cmp = "Cmp";
        public const string Jmp = "jmp";
        public const string Set = "set";
        public const string JmpCC = "JmpCC";
        //public const string SetCC = "SetCC";
        public const string Label = "Label";
        public const string Comment = "Comment";
    }
}
