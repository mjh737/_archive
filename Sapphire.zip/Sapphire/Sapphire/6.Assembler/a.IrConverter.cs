﻿namespace Sapphire.Converter
{
    using Sapphire.Assembler.Functions;
    using Sapphire.Assembler.Instructions;
    using Sapphire.Assembler.Operands;
    using Sapphire.Exceptions;
    using Sapphire.Resolver;
    using Sapphire.XGenerator;
    using System.Collections.Generic;

    public class IrConverter
    {
        private const string FunctionEndLabel = "__func_end";

        public AsmProgram Lower(IrProgram prog)
        {
            var loweredFunction = LowerFunction(prog.Function);
            return new AsmProgram(prog.Name, new List<AsmFunction> { loweredFunction });
        }

        private AsmFunction LowerFunction(IrFunction function)
        {
            var instrs = LowerInstructions(function.Instructions);
            // Ensure a unified function end label exists as a jump target for early returns
            instrs.Add(new AsmInstruction(AsmInstructions.Label, new AsmOperand(AsmOperands.Label, FunctionEndLabel)));
            return new AsmFunction(function.Name.OriginalName, instrs, function.Location);
        }


        private List<AsmInstruction> LowerInstructions(List<IrInstruction> tac)
        {
            var instructions = new List<AsmInstruction>();

            foreach (var instr in tac)
            {
                switch (instr)
                {
                    case TacMov mov: instructions.Add(new AsmInstruction(AsmInstructions.Mov, ConvertTacValToOperand(mov.Source), ConvertTacValToOperand(mov.Destination))); break;
                    case IrUnary un: instructions.AddRange(GetUnaryInstructions(un)); break;
                    case IrBinary bin: instructions.AddRange(GetBinaryInstructions(bin)); break;
                    case IrReturn ret: instructions.AddRange(GetReturnInstructions(ret)); break;
                    case IrJumpIfZero jz: instructions.AddRange(GetJzInstructions(jz)); break;
                    case IrJumpIfNotZero jnz: instructions.AddRange(GetJnzInstructions(jnz)); break;
                    case IrJump jmp: instructions.Add(AsmInstruction.Jmp(jmp.Target));

                        break;

                    case IrCopy cpy: instructions.Add(new AsmInstruction(AsmInstructions.Mov, ConvertTacValToOperand(cpy.Source), ConvertTacValToOperand(cpy.Destination))); break;
                    case IrLabel label:
                        instructions.Add(new AsmInstruction(
                            AsmInstructions.Label,
                            new AsmOperand(AsmOperands.Label, label.Identifier)
                        ));
                        break;
                    case IrComment jnz: instructions.Add(new AsmComment(jnz.Text, jnz.Location, jnz.SemanticTag)); break;
                    //case TacVar var: instructions.Add(new AsmInstruction(AsmInstructions.))
                    default:
                        instructions.Add(new AsmInstruction("; <unhandled: " + instr.GetType().Name + ">"));
                        break;
                }
            }

            return instructions;
        }

        // Confirmed: both paths now emit conditional jumps with JmpCC
        private IEnumerable<AsmInstruction> GetJzInstructions(IrJumpIfZero jz)
        {
            var cmp = new AsmInstruction(
                AsmInstructions.Cmp,
                ConvertTacValToOperand(new IrLiteral(0)),
                ConvertTacValToOperand(jz.Condition));

            var jmp = new AsmConditionalInstruction(AsmInstructions.JmpCC, AsmConditionCodes.E, jz.Target);
            return new List<AsmInstruction> { cmp, jmp };
        }

        private IEnumerable<AsmInstruction> GetJnzInstructions(IrJumpIfNotZero jnz)
        {
            var cmp = new AsmInstruction(
                AsmInstructions.Cmp,
                ConvertTacValToOperand(new IrLiteral(0)),
                ConvertTacValToOperand(jnz.Condition));

            var jmp = new AsmConditionalInstruction(AsmInstructions.JmpCC, AsmConditionCodes.NE, jnz.Target);
            return new List<AsmInstruction> { cmp, jmp };
        }

        private List<AsmInstruction> GetReturnInstructions(IrReturn ret)
        {
            var sourceOperand = ConvertTacValToOperand(ret.Value);

            var moveToEax = new AsmInstruction(
                AsmInstructions.Mov,
                sourceOperand,
                new AsmOperand(AsmOperands.Reg, Registers.EAX)
            );

            // Jump to unified epilogue label instead of emitting a raw Ret here
            var jumpToEnd = AsmInstruction.Jmp(FunctionEndLabel);

            return new List<AsmInstruction> { moveToEax, jumpToEnd };
        }


        private List<AsmInstruction> GetUnaryInstructions(IrUnary un)
        {
            AsmOperand dst = ConvertTacValToOperand(un.Destination);

            AsmInstruction i1;
            AsmInstruction i2;

            switch (un.Operator)
            {
                case IrUnaryOperator.Not:
                    // result = (source == 0) ? 1 : 0
                    var cmp = new AsmInstruction(AsmInstructions.Cmp, new AsmOperand(AsmOperands.Imm, 0), ConvertTacValToOperand(un.Source));
                    var movZero = new AsmInstruction(AsmInstructions.Mov, new AsmOperand(AsmOperands.Imm, 0), dst);

                    // If not equal, skip setting 1
                    string endLabel = $"not_{dst.Identifier}_end";
                    var jmpNe = new AsmConditionalInstruction(AsmInstructions.JmpCC, AsmConditionCodes.NE, endLabel);

                    var movOne = new AsmInstruction(AsmInstructions.Mov, new AsmOperand(AsmOperands.Imm, 1), dst);
                    var label = new AsmInstruction(AsmInstructions.Label, new AsmOperand(AsmOperands.Label, endLabel));

                    return new List<AsmInstruction> { cmp, movZero, jmpNe, movOne, label };

                case IrUnaryOperator.Negate:
                    i1 = new AsmInstruction(AsmInstructions.Mov, ConvertTacValToOperand(un.Source), dst);
                    i2 = new AsmInstruction(AsmInstructions.Neg, dst);
                    break;

                case IrUnaryOperator.Complement:
                    i1 = new AsmInstruction(AsmInstructions.Mov, ConvertTacValToOperand(un.Source), dst);
                    i2 = new AsmInstruction(AsmInstructions.Not, dst);
                    break;

                default:
                    i1 = new AsmInstruction(AsmInstructions.Mov, ConvertTacValToOperand(un.Source), dst);
                    i2 = new AsmInstruction(un.Operator.ToString(), dst);
                    break;
            }

            return new List<AsmInstruction> { i1, i2 };
        }

        private List<AsmInstruction> GetBinaryInstructions(IrBinary bin)
        {
            switch (bin.Operator)
            {
                case IrBinaryOperator.Divide: return GetDivisionInstructions(bin);
                case IrBinaryOperator.Modulo: return GetModuloInstructions(bin);
                case IrBinaryOperator.EqualEqual: return GetRelationalOperatorInstructions(bin);
                case IrBinaryOperator.NotEqual: return GetRelationalOperatorInstructions(bin);
                case IrBinaryOperator.GreaterThan: return GetRelationalOperatorInstructions(bin);
                case IrBinaryOperator.GreaterThanOrEqual: return GetRelationalOperatorInstructions(bin);
                case IrBinaryOperator.LessThan: return GetRelationalOperatorInstructions(bin);
                case IrBinaryOperator.LessThanOrEqual: return GetRelationalOperatorInstructions(bin);
                default:
                    return GetOtherBinaryInstructions(bin);
            }
        }

        private List<AsmInstruction> GetDivisionInstructions(IrBinary bin)
        {
            AsmOperand dst = ConvertTacValToOperand(bin.Destination);

            AsmInstruction i1 = new AsmInstruction(AsmInstructions.Mov, ConvertTacValToOperand(bin.Source1), new AsmOperand(AsmOperands.Reg, Registers.EAX));
            AsmInstruction i2 = new AsmInstruction(AsmInstructions.Cdq);
            AsmInstruction i3 = new AsmInstruction(AsmInstructions.Idiv, ConvertTacValToOperand(bin.Source2));
            AsmInstruction i4 = new AsmInstruction(AsmInstructions.Mov, new AsmOperand(AsmOperands.Reg, Registers.EAX), dst);

            return new List<AsmInstruction> { i1, i2, i3, i4 };
        }

        private List<AsmInstruction> GetModuloInstructions(IrBinary bin)
        {
            AsmOperand dst = ConvertTacValToOperand(bin.Destination);

            AsmInstruction i1 = new AsmInstruction(AsmInstructions.Mov, ConvertTacValToOperand(bin.Source1), new AsmOperand(AsmOperands.Reg, Registers.EAX));
            AsmInstruction i2 = new AsmInstruction(AsmInstructions.Cdq);
            AsmInstruction i3 = new AsmInstruction(AsmInstructions.Idiv, ConvertTacValToOperand(bin.Source2));
            AsmInstruction i4 = new AsmInstruction(AsmInstructions.Mov, new AsmOperand(AsmOperands.Reg, Registers.EDX), dst);

            return new List<AsmInstruction> { i1, i2, i3, i4 };
        }

        private List<AsmInstruction> GetRelationalOperatorInstructions(IrBinary bin)
        {
            // Map IR relop to Jcc condition
            AsmConditionCodes cc = (bin.Operator) switch
            {
                IrBinaryOperator.EqualEqual => AsmConditionCodes.E,
                IrBinaryOperator.NotEqual => AsmConditionCodes.NE,
                IrBinaryOperator.GreaterThan => AsmConditionCodes.G,
                IrBinaryOperator.GreaterThanOrEqual => AsmConditionCodes.GE,
                IrBinaryOperator.LessThan => AsmConditionCodes.L,
                IrBinaryOperator.LessThanOrEqual => AsmConditionCodes.LE,
                _ => throw new ConverterException($"Invalid Relational Operator {bin.Operator}")
            };

            AsmOperand dst = ConvertTacValToOperand(bin.Destination);

            string trueLabel = VariableMap.MakeLabel("rel_true");
            string endLabel = VariableMap.MakeLabel("rel_end");

            var i1 = new AsmInstruction(AsmInstructions.Cmp, ConvertTacValToOperand(bin.Source2), ConvertTacValToOperand(bin.Source1));
            var i2 = new AsmInstruction(AsmInstructions.Mov, new AsmOperand(AsmOperands.Imm, 0), dst);
            // Emit real conditional jump (jcc) to true label
            var i3 = new AsmConditionalInstruction(AsmInstructions.JmpCC, cc, trueLabel);
            var i4 = AsmInstruction.Jmp(endLabel);
            var i5 = new AsmInstruction(AsmInstructions.Label, new AsmOperand(AsmOperands.Label, trueLabel));
            var i6 = new AsmInstruction(AsmInstructions.Mov, new AsmOperand(AsmOperands.Imm, 1), dst);
            var i7 = new AsmInstruction(AsmInstructions.Label, new AsmOperand(AsmOperands.Label, endLabel));

            return new List<AsmInstruction> { i1, i2, i3, i4, i5, i6, i7 };
        }

        private List<AsmInstruction> GetOtherBinaryInstructions(IrBinary bin)
        {
            AsmOperand dst = ConvertTacValToOperand(bin.Destination);

            AsmInstruction i1 = new AsmInstruction(AsmInstructions.Mov, ConvertTacValToOperand(bin.Source1), dst);
            AsmInstruction i2;

            switch (bin.Operator)
            {
                case IrBinaryOperator.Multiply: i2 = new AsmInstruction(AsmInstructions.Mul, ConvertTacValToOperand(bin.Source2), dst); break;
                case IrBinaryOperator.Subtract: i2 = new AsmInstruction(AsmInstructions.Sub, ConvertTacValToOperand(bin.Source2), dst); break;
                case IrBinaryOperator.Add: i2 = new AsmInstruction(AsmInstructions.Add, ConvertTacValToOperand(bin.Source2), dst); break;

                default: throw new ConverterException($"Invalid binary operator:{bin.Operator.ToString()}");
            }

            return new List<AsmInstruction> { i1, i2 };
        }

        private AsmOperand ConvertTacValToOperand(IrVal val)
        {
            switch (val)
            {
                case IrVar var:
                    return new AsmOperand(AsmOperands.Pseudo, var.Name);

                case IrVal unit when ReferenceEquals(unit, IrVal.Unit):
                    return new AsmOperand(AsmOperands.Imm, "0");

                case IrLiteral literal:
                    return new AsmOperand(AsmOperands.Imm, literal.Value);

                case Identifier id:
                    return new AsmOperand(AsmOperands.Label, id.OriginalName);

                default:
                    throw new ConverterException($"Invalid Operand: {val}");
            }

        }
    }
}
