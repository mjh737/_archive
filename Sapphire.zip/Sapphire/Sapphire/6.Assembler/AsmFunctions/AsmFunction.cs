﻿namespace Sapphire.Assembler.Functions
{
    using Sapphire.Assembler.Instructions;
    using Sapphire.Misc;
    using System.Collections.Generic;

    public record AsmFunction(string Name, List<AsmInstruction> Instructions, SourceLocation Location)
    {
        public AsmFunction(string name) : this(name, new(), SourceLocation.Unknown) { }

        public override string ToString() => $"Function({Name}) @ {Location}";
    }

}
