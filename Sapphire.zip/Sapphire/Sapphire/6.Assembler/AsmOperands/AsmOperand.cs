﻿namespace Sapphire.Assembler.Operands
{
    public class AsmOperand
    {
        private readonly AsmOperands _opType;
        private readonly int _value;
        private readonly string _identifier;

        public AsmOperands OpType => _opType;
        public int Value => _value;
        public string Identifier => _identifier;

        public AsmOperand()
        {
            _opType = AsmOperands.None;
            _value = 0;
            _identifier = "";
        }

        public AsmOperand(AsmOperands opType, int value)
        {
            if (opType != AsmOperands.Imm && opType != AsmOperands.Stack &&
                opType != AsmOperands.None)
                throw new ArgumentException("Invalid Operand");

            _opType = opType;
            _value = value;
            _identifier = "";
        }

        public AsmOperand(AsmOperands opType, string identifier)
        {
            if (opType != AsmOperands.Reg &&
                opType != AsmOperands.Pseudo &&
                opType != AsmOperands.Label &&
                opType != AsmOperands.Imm &&
                opType != AsmOperands.Comment)
                throw new ArgumentException($"Invalid Operand Type: {opType}");

            _opType = opType;
            _identifier = identifier;
            _value = 0;
        }

        public override string ToString()
        {
            return _opType switch
            {
                AsmOperands.Imm => $"Imm({_value})",
                AsmOperands.Pseudo => $"Pseudo({_identifier})",
                AsmOperands.Reg => $"Reg({_identifier})",
                AsmOperands.Stack => $"Stack({_value})",
                AsmOperands.Label => $"Label({_identifier})",
                AsmOperands.None => "",
                _ => throw new NotImplementedException()
            };
        }

        public string ToAsmString()
        {
            return _opType switch
            {
                AsmOperands.Imm => _value.ToString(),
                AsmOperands.Pseudo => _identifier,
                AsmOperands.Reg => _identifier,
                AsmOperands.Stack => $"dword [rbp-{_value}]",
                AsmOperands.Comment => _identifier,
                AsmOperands.Label => _identifier,
                AsmOperands.None => "",
                _ => throw new NotImplementedException()
            };
        }


        // Plan:
        // - Add AsmOperands.Comment case to ToAsmValue switch expression to avoid NotImplementedException.
        // - Return the identifier for comments, consistent with ToAsmString.
        // - Keep existing behavior for all other operand types.

        public string ToAsmValue()
        {
            return _opType switch
            {
                AsmOperands.Imm => $"{_value}",
                AsmOperands.Pseudo => $"{_identifier}",
                AsmOperands.Reg => $"{_identifier}",
                AsmOperands.Label => $"{_identifier}",
                AsmOperands.Comment => $"{_identifier}",
                AsmOperands.Stack => $"dword [rbp-{_value}]",
                AsmOperands.None => "",
                _ => throw new NotImplementedException()
            };
        }

        public static AsmOperand None() => new AsmOperand(AsmOperands.None, 0);
    }
}