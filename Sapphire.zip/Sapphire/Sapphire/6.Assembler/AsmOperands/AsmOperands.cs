﻿namespace Sapphire.Assembler.Operands
{
    public enum AsmOperands
    {
        None,
        Imm,
        Reg,
        Pseudo,
        Stack,
        Label,
        Comment,
        Mem
    }
}
