﻿namespace Sapphire.Replacer
{
    public class LabelAllocator
    {
        private readonly Dictionary<string, string> labelMap = new();
        private int counter = 0;

        public string GetLabel(string key)
        {
            if (string.IsNullOrWhiteSpace(key))
                return "";

            if (labelMap.TryGetValue(key, out var label))
                return label;

            var sanitized = Sanitize(key);
            label = sanitized;

            // Only append counter if sanitized label already exists
            while (labelMap.Values.Contains(label))
                label = sanitized + "_" + counter++;

            labelMap[key] = label;
            return label;
        }


        public IEnumerable<string> AllLabels => labelMap.Values;

        public bool TryGetOriginal(string label, out string original)
        {
            foreach (var kvp in labelMap)
            {
                if (kvp.Value == label)
                {
                    original = kvp.Key;
                    return true;
                }
            }

            original = null;
            return false;
        }

        private string Sanitize(string raw)
        {
            // Replace invalid characters for label names
            return raw.Replace('.', '_')
                      .Replace('-', '_')
                      .Replace(':', '_')
                      .Replace(' ', '_');
        }
    }
}