﻿namespace Sapphire.Rewriter
{
    using Sapphire.Assembler.Functions;
    using Sapphire.Assembler.Instructions;
    using Sapphire.Assembler.Operands;
    using Sapphire.Converter;
    using System.Collections.Generic;

    public class InstructionRewriter
    {
        public AsmProgram Run(AsmProgram prog, int stackOffset)
        {
            return new AsmProgram(prog.Name, prog.Functions
                .Select(f => UpdateFunction(f, stackOffset))
                .ToList());
        }

        private AsmFunction UpdateFunction(AsmFunction function, int stackOffset)
        {
            var newInstructions = new List<AsmInstruction>();

            // Emit stack allocation once at the beginning of the function body
            if (stackOffset > 0)
            {
                newInstructions.Add(new AsmInstruction(AsmInstructions.AllocateStack, new AsmOperand(AsmOperands.Stack, stackOffset)));
            }

            foreach (var instruction in function.Instructions)
            {
                // Rewrite mov mem, imm => mov r11, imm; mov mem, r11
                if (instruction.Mnemonic == AsmInstructions.Mov && instruction.Operand2.OpType == AsmOperands.Imm)
                {
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Mov, instruction.Operand2, new AsmOperand(AsmOperands.Reg, Registers.R11)));
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Mov, new AsmOperand(AsmOperands.Reg, Registers.R11), instruction.Operand1));
                }
                // Rewrite mov mem, mem => mov r11, srcMem; mov dstMem, r11
                else if (instruction.Mnemonic == AsmInstructions.Mov
                         && IsMemoryLike(instruction.Operand1)
                         && IsMemoryLike(instruction.Operand2))
                {
                    // operand1 is source in our IR shape (Emitter prints dest, src)
                    var srcMem = instruction.Operand1;
                    var dstMem = instruction.Operand2;
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Mov, srcMem, new AsmOperand(AsmOperands.Reg, Registers.R11)));
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Mov, new AsmOperand(AsmOperands.Reg, Registers.R11), dstMem));
                }
                // Rewrite cmp mem, imm => mov r11, imm; cmp mem, r11
                else if (instruction.Mnemonic == AsmInstructions.Cmp && instruction.Operand2.OpType == AsmOperands.Imm)
                {
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Mov, instruction.Operand2, new AsmOperand(AsmOperands.Reg, Registers.R11)));
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Cmp, instruction.Operand1, new AsmOperand(AsmOperands.Reg, Registers.R11)));
                }
                // Rewrite cmp mem, mem => mov r11, srcMem; cmp dstMem, r11
                else if (instruction.Mnemonic == AsmInstructions.Cmp
                         && IsMemoryLike(instruction.Operand1)
                         && IsMemoryLike(instruction.Operand2))
                {
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Mov, instruction.Operand1, new AsmOperand(AsmOperands.Reg, Registers.R11)));
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Cmp, new AsmOperand(AsmOperands.Reg, Registers.R11), instruction.Operand2));
                }
                // Rewrite idiv imm => mov r11, imm; idiv r11 (idiv requires r/m32)
                else if (instruction.Mnemonic == AsmInstructions.Idiv && instruction.Operand1.OpType == AsmOperands.Imm)
                {
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Mov, instruction.Operand1, new AsmOperand(AsmOperands.Reg, Registers.R11)));
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Idiv, new AsmOperand(AsmOperands.Reg, Registers.R11)));
                }
                // Rewrite imul when destination is memory/stack => load dest to r11; imul r11, src; mov back
                else if (instruction.Mnemonic == AsmInstructions.Mul && IsMemoryLike(instruction.Operand2))
                {
                    var dstMem = instruction.Operand2;
                    // load destination to r11d
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Mov, dstMem, new AsmOperand(AsmOperands.Reg, Registers.R11)));
                    // perform imul r11d, src (Emitter prints: imul dst, src)
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Mul, instruction.Operand1, new AsmOperand(AsmOperands.Reg, Registers.R11)));
                    // store back
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Mov, new AsmOperand(AsmOperands.Reg, Registers.R11), dstMem));
                }
                // Rewrite add/sub/mul mem, mem => mov r11, srcMem; op dstMem, r11
                else if ((instruction.Mnemonic == AsmInstructions.Add
                          || instruction.Mnemonic == AsmInstructions.Sub
                          || instruction.Mnemonic == AsmInstructions.Mul)
                         && IsMemoryLike(instruction.Operand1)
                         && IsMemoryLike(instruction.Operand2))
                {
                    newInstructions.Add(new AsmInstruction(AsmInstructions.Mov, instruction.Operand1, new AsmOperand(AsmOperands.Reg, Registers.R11)));
                    newInstructions.Add(new AsmInstruction(instruction.Mnemonic, new AsmOperand(AsmOperands.Reg, Registers.R11), instruction.Operand2));
                }
                else if ((instruction.Mnemonic == AsmInstructions.Jmp || instruction.Mnemonic == AsmInstructions.JmpCC)
                         && instruction.Operand1.OpType == AsmOperands.Label)
                {
                    // Preserve symbolic conditional jumps intact
                    newInstructions.Add(instruction);
                }
                else
                {
                    newInstructions.Add(instruction);
                }
            }

            // Peephole cleanup to reduce redundant mov sequences
            newInstructions = PeepholeSimplify(newInstructions);

            return new AsmFunction(function.Name, newInstructions, function.Location);
        }

        private static bool IsMemoryLike(AsmOperand op)
        {
            return op.OpType == AsmOperands.Mem || op.OpType == AsmOperands.Stack;
        }

        private static List<AsmInstruction> PeepholeSimplify(List<AsmInstruction> input)
        {
            var outList = new List<AsmInstruction>();
            int i = 0;
            while (i < input.Count)
            {
                var cur = input[i];

                // Pattern A: mov regX, memA/stackA; mov memA/stackA, regX  => remove both (no-op)
                if (i + 1 < input.Count
                    && cur.Mnemonic == AsmInstructions.Mov
                    && input[i + 1].Mnemonic == AsmInstructions.Mov
                    && cur.Operand2.OpType == AsmOperands.Reg
                    && IsMemoryLike(cur.Operand1))
                {
                    var next = input[i + 1];
                    bool nextIsStoreBack = IsMemoryLike(next.Operand2)
                                           && next.Operand1.OpType == AsmOperands.Reg
                                           && OperandEqualsReg(next.Operand1, cur.Operand2)
                                           && OperandEqualsMemLike(next.Operand2, cur.Operand1);
                    if (nextIsStoreBack)
                    {
                        // Drop both
                        i += 2;
                        continue;
                    }
                }

                // Pattern B: mov regX, imm/regY; mov dest, regX => mov dest, imm/regY (avoid creating mem->mem)
                if (i + 1 < input.Count
                    && cur.Mnemonic == AsmInstructions.Mov
                    && input[i + 1].Mnemonic == AsmInstructions.Mov
                    && cur.Operand2.OpType == AsmOperands.Reg)
                {
                    var next = input[i + 1];
                    if (next.Operand1.OpType == AsmOperands.Reg
                        && OperandEqualsReg(next.Operand1, cur.Operand2)
                        && !IsMemoryLike(cur.Operand1)) // don't create mem/stack -> mem fusion
                    {
                        // Replace second with mov dest, src and drop first
                        var fused = new AsmInstruction(AsmInstructions.Mov, cur.Operand1, next.Operand2);
                        outList.Add(fused);
                        i += 2;
                        continue;
                    }
                }

                outList.Add(cur);
                i++;
            }
            return outList;
        }

        private static bool OperandEqualsReg(AsmOperand a, AsmOperand b)
        {
            return a.OpType == AsmOperands.Reg && b.OpType == AsmOperands.Reg && a.Identifier == b.Identifier;
        }

        private static bool OperandEqualsMemLike(AsmOperand a, AsmOperand b)
        {
            // Compare memory-like operands (mem or stack) by identifier/value
            bool aMem = a.OpType == AsmOperands.Mem || a.OpType == AsmOperands.Stack;
            bool bMem = b.OpType == AsmOperands.Mem || b.OpType == AsmOperands.Stack;
            return aMem && bMem && a.Identifier == b.Identifier && a.Value == b.Value;
        }
    }
}
