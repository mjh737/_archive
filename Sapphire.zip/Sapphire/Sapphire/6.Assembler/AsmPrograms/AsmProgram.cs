﻿namespace Sapphire.Converter
{
    using Sapphire.Assembler.Functions;

    public record AsmProgram(string Name, List<AsmFunction> Functions)
    {
        public AsmProgram(string name) : this(name, new()) { }

        public override string ToString() => $"Program({Name})";
    }
}
