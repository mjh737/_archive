﻿namespace Sapphire.Exceptions
{
    using Sapphire.Misc;
    using System;

    [Serializable]
    public class ResolverException : Exception
    {
        public SourceLocation Location { get; }

        public ResolverException(string message, SourceLocation location)
            : base($"{message} at {location}")
        {
            Location = location;
        }

        public ResolverException(string message, SourceLocation location, Exception innerException)
            : base($"{message} at {location}", innerException)
        {
            Location = location;
        }
    }
}