﻿namespace Sapphire.Exceptions
{
    using Sapphire.Misc;
    using System;

    [Serializable]
    public class ParserException : CompilerException
    {
        public SourceLocation Location { get; }

        public ParserException(string message, SourceLocation location)
        : base($"{message} @ {location}")
        {
            Location = location;
        }


        public ParserException(string? message, SourceLocation location, Exception? innerException) : base(message, innerException)
        {
        }
    }
}