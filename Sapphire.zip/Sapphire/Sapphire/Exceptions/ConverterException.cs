﻿namespace Sapphire.Exceptions
{
    using System;

    [Serializable]
    public class ConverterException : Exception
    {
        public ConverterException()
        {
        }

        public ConverterException(string? message) : base(message)
        {
        }

        public ConverterException(string? message, Exception? innerException) : base(message, innerException)
        {
        }
    }
}