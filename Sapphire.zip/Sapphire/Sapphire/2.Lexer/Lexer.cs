﻿namespace Sapphire.XLexer
{
    using Sapphire.Exceptions;
    using Sapphire.Misc;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text.RegularExpressions;

    public class Lexer
    {
        List<Token> _tokens = new List<Token>();

        int _position = 0;

        string _current = "";

        string _input;

        private int _line = 1;
        private int _column = 1;
        private int _currentStartLine;
        private int _currentStartColumn;


        char[] _singleCharTokens = [')', '(', ';', '{', '}', '-', '~', '+', '*', '/', '%', '=', '!', '>', '<', '?', ':', ','];

        // Pseudocode:
        // - Split the input into lines
        // - Trim each line to remove leading/trailing whitespace
        // - Filter out lines that start with '#', '/*', or '*/'
        // - Join the remaining lines back with Environment.NewLine
        //public static string RemoveCommentLines(string input)
        //{
        //    var lines = input
        //        .Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None)
        //        .Select(static line => line.Trim())
        //        .ToArray();

        //    // Remove line comments (// ...)
        //    string noLineComments = Regex.Replace(
        //        noBlockComments,
        //        @"//.*?$",
        //        "",
        //        RegexOptions.Multiline
                

        //    // Remove preprocessor directives (# at start of line)
        //    string noDirectives = Regex.Replace(
        //        noLineComments,
        //        @"^\s*#.*?$",
        //        "",
        //        RegexOptions.Multiline
        //    );

        //    return noDirectives;
        //}

        public static string RemoveCommentsAndDirectives(string input)
        {
            // Remove block comments (/* ... */), including multiline
            string noBlockComments = Regex.Replace(
                input,
                @"/\*.*?\*/",
                "",
                RegexOptions.Singleline
            );

            // Remove line comments (// ...)
            string noLineComments = Regex.Replace(
                noBlockComments,
                @"//.*?$",
                "",
                RegexOptions.Multiline
            );

            // Remove preprocessor directives (# at start of line)
            string noDirectives = Regex.Replace(
                noLineComments,
                @"^\s*#.*?$",
                "",
                RegexOptions.Multiline
            );

            return noDirectives;
        }

        public List<Token> Run(string input)
        {
            _input = RemoveCommentsAndDirectives(input);
            _input = _input.Replace("\r", "").Replace("\t", " ").Trim();
            _position = 0;
            _line = 1;
            _column = 1;
            _current = "";
            _tokens.Clear();

            while (_position < _input.Length)
            {
                char currentChar = _input[_position];

                // Handle newline
                if (currentChar == '\n')
                {
                    FlushCurrentToken();
                    _position++;
                    _line++;
                    _column = 1;
                    continue;
                }

                // Skip whitespace
                if (char.IsWhiteSpace(currentChar))
                {
                    FlushCurrentToken();
                    _position++;
                    _column++;
                    continue;
                }

                // Skip line comments
                if (currentChar == '/' && Peek(1) == '/')
                {
                    FlushCurrentToken();
                    int startLine = _line;
                    int startColumn = _column;

                    _position += 2;
                    _column += 2;

                    var commentText = "";
                    while (_position < _input.Length && _input[_position] != '\n')
                    {
                        commentText += _input[_position];
                        _position++;
                        _column++;
                    }

                    var location = new SourceLocation(startLine, startColumn, _line, _column - 1);
                    _tokens.Add(new Token(commentText.Trim(), TokenTypes.Comment, location));
                    continue;
                }


                // Skip block comments
                if (currentChar == '/' && Peek(1) == '*')
                {
                    FlushCurrentToken();
                    int startLine = _line;
                    int startColumn = _column;

                    _position += 2;
                    _column += 2;

                    var commentText = "";
                    while (_position + 1 < _input.Length &&
                           !(_input[_position] == '*' && _input[_position + 1] == '/'))
                    {
                        commentText += _input[_position];

                        if (_input[_position] == '\n')
                        {
                            _line++;
                            _column = 1;
                        }
                        else
                        {
                            _column++;
                        }

                        _position++;
                    }

                    _position += 2;
                    _column += 2;

                    var location = new SourceLocation(startLine, startColumn, _line, _column - 1);
                    _tokens.Add(new Token(commentText.Trim(), TokenTypes.Comment, location));
                    continue;
                }

                // Multi-character operator
                if (IsMultiCharOperator(currentChar, Peek(1)))
                {
                    FlushCurrentToken();
                    int startLine = _line;
                    int startColumn = _column;

                    string op = $"{currentChar}{Peek(1)}";
                    _position += 2;
                    _column += 2;

                    var location = new SourceLocation(startLine, startColumn, _line, _column - 1);
                    _tokens.Add(new Token(op, TokenTypes.Lookup(op), location));
                    continue;
                }

                // Single-character token
                if (_singleCharTokens.Contains(currentChar))
                {
                    FlushCurrentToken();
                    int startLine = _line;
                    int startColumn = _column;

                    _position++;
                    _column++;

                    var location = new SourceLocation(startLine, startColumn, _line, _column - 1);
                    _tokens.Add(new Token(currentChar.ToString(), TokenTypes.Lookup(currentChar.ToString()), location));
                    continue;
                }

                // Accumulate characters
                if (_current.Length == 0)
                {
                    _currentStartLine = _line;
                    _currentStartColumn = _column;
                }

                _current += currentChar;
                _position++;
                _column++;
            }

            FlushCurrentToken();

            if (_tokens.Count == 0)
                throw new LexerException("No tokens identified");

            return _tokens;
        }

        private static Token GetSingleCharacterToken(char ch, int line, int column)
        {
            var value = ch.ToString();
            var location = new SourceLocation(line, column, line, column);

            return value switch
            {
                "(" => new Token(value, TokenTypes.OpenBracket, location),
                ")" => new Token(value, TokenTypes.CloseBracket, location),
                "{" => new Token(value, TokenTypes.OpenCurlyBrace, location),
                "}" => new Token(value, TokenTypes.CloseCurlyBrace, location),
                ";" => new Token(value, TokenTypes.Semicolon, location),
                "~" => new Token(value, TokenTypes.Complement, location),
                "+" => new Token(value, TokenTypes.Add, location),
                "-" => new Token(value, TokenTypes.Negate, location),
                "*" => new Token(value, TokenTypes.Multiply, location),
                "/" => new Token(value, TokenTypes.Divide, location),
                "%" => new Token(value, TokenTypes.Modulo, location),
                "!" => new Token(value, TokenTypes.Not, location),
                "<" => new Token(value, TokenTypes.LessThan, location),
                ">" => new Token(value, TokenTypes.GreaterThan, location),
                "=" => new Token(value, TokenTypes.Equal, location),
                "?" => new Token(value, TokenTypes.QuestionMark, location),
                ":" => new Token(value, TokenTypes.Colon, location),
                "," => new Token(value, TokenTypes.Comma, location),
                _ => new Token(value, TokenTypes.Invalid, location)
            };
        }

        private Token GetToken(string input, int line, int column)
        {
            var location = new SourceLocation(line, column, line, column + input.Length - 1);
            var type = TokenTypes.Infer(input);
            return new Token(input, type, location);
        }


        private char Peek(int offset)
        {
            return (_position + offset < _input.Length) ? _input[_position + offset] : '\0';
        }

        private void FlushCurrentToken()
        {
            if (!string.IsNullOrEmpty(_current))
            {
                Token token = GetToken(_current, _currentStartLine, _currentStartColumn);
                _tokens.Add(token); // Add it regardless of validity
                _current = "";
            }
        }


        private bool IsMultiCharOperator(char first, char second)
        {
            string op = $"{first}{second}";
            return op == "--" || op == "&&" || op == "||" ||
                   op == "==" || op == "!=" || op == "<=" || op == ">=";
        }
    }
}
