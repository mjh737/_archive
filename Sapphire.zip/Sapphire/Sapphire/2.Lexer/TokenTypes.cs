﻿namespace Sapphire.XLexer
{
    using Sapphire.Exceptions;
    using System;

    public static class TokenTypes
    {
        public const string Invalid = "Invalid";
        public const string Identifier = "Identifier";
        public const string IntKeyword = "IntKeyword";
        public const string ReturnKeyword = "ReturnKeyword";
        public const string IfKeyword = "IfKeyword";
        public const string DoKeyword = "DoKeyword";
        public const string WhileKeyword = "WhileKeyword";
        public const string ForKeyword = "ForKeyword";
        public const string BreakKeyword = "BreakKeyword";
        public const string ContinueKeyword = "ContinueKeyword";
        public const string ThenKeyword = "ThenKeyword";
        public const string ElseKeyword = "ElseKeyword";
        public const string QuestionMark = "QuestionMark";
        public const string Colon = "Colon";
        public const string VoidKeyword = "VoidKeyword";
        public const string Constant = "Constant";
        public const string OpenBracket = "OpenBracket";
        public const string CloseBracket = "CloseBracket";
        public const string OpenCurlyBrace = "OpenCurlyBrace";
        public const string CloseCurlyBrace = "CloseCurlyBrace";
        public const string Semicolon = "Semicolon";
        public const string Complement = "Complement";
        public const string Negate = "Negate";
        public const string Decrement = "Decrement";
        public const string Add = "Add";
        public const string Multiply = "Multiply";
        public const string Divide = "Divide";
        public const string Modulo = "Modulo";

        public const string Not = "Not";
        public const string And = "And";
        public const string Or = "Or";
        public const string Equal = "Equal";
        public const string EqualEqual = "EqualEqual";
        public const string NotEqual = "NotEqual";
        public const string LessThan = "LessThan";
        public const string GreaterThan = "GreaterThan";
        public const string LessOrEqualTo = "LessOrEqualTo";
        public const string GreaterOrEqualTo = "GreaterOrEqualTo";

        public const string Comment = "Comment";
        public const string Comma = "Comma";

        public static bool IsStatementStart(string tokenType)
        {
            return tokenType switch
            {
                TokenTypes.IfKeyword => true,
                TokenTypes.ForKeyword => true,
                TokenTypes.WhileKeyword => true,
                TokenTypes.DoKeyword => true,
                TokenTypes.ReturnKeyword => true,
                TokenTypes.BreakKeyword => true,
                TokenTypes.ContinueKeyword => true,
                TokenTypes.OpenCurlyBrace => true,
                TokenTypes.Semicolon => true,
                _ => false
            };
        }



        public static bool IsExpressionStart(string tokenType)
        {
            return tokenType == Identifier;
        }

        public static bool IsTypeKeyword(string tokenType)
        {
            return tokenType == IntKeyword;
        }

        private static bool IsValidIdentifier(string value)
        {
            return !string.IsNullOrEmpty(value) &&
                   (char.IsLetter(value[0]) || value[0] == '_') &&
                   value.All(c => char.IsLetterOrDigit(c) || c == '_');
        }

        internal static string Lookup(string v)
        {
            // Keywords
            return v switch
            {
                "int" => IntKeyword,
                "return" => ReturnKeyword,
                "if" => IfKeyword,
                "do" => DoKeyword,
                "while" => WhileKeyword,
                "for" => ForKeyword,
                "break" => BreakKeyword,
                "continue" => ContinueKeyword,
                "then" => ThenKeyword,
                "else" => ElseKeyword,
                "void" => VoidKeyword,

                // Symbols
                "(" => OpenBracket,
                ")" => CloseBracket,
                "{" => OpenCurlyBrace,
                "}" => CloseCurlyBrace,
                ";" => Semicolon,
                ":" => Colon,
                "?" => QuestionMark,

                // Operators
                "~" => Complement,
                "!" => Not,
                "-" => Negate,
                "--" => Decrement,
                "+" => Add,
                "*" => Multiply,
                "/" => Divide,
                "%" => Modulo,
                "&&" => And,
                "||" => Or,
                "=" => Equal,
                "==" => EqualEqual,
                "!=" => NotEqual,
                "<" => LessThan,
                ">" => GreaterThan,
                "<=" => LessOrEqualTo,
                ">=" => GreaterOrEqualTo,

                _ => InferFallback(v)
            };
        }

        private static string InferFallback(string value)
        {
            if (int.TryParse(value, out _))
                return Constant;

            if (IsValidIdentifier(value))
                return Identifier;

            return Invalid;
        }

        public static string Infer(string value)
        {
            if (string.IsNullOrEmpty(value))
                return Invalid;

            if (value == "--") return Decrement;
            if (value == "&&") return And;
            if (value == "||") return Or;
            if (value == "==") return EqualEqual;
            if (value == "!=") return NotEqual;
            if (value == "<=") return LessOrEqualTo;
            if (value == ">=") return GreaterOrEqualTo;

            if (int.TryParse(value, out _))
                return Constant;

            if (IsValidIdentifier(value))
            {
                return value switch
                {
                    "int" => IntKeyword,
                    "return" => ReturnKeyword,
                    "void" => VoidKeyword,
                    "if" => IfKeyword,
                    "then" => ThenKeyword,
                    "else" => ElseKeyword,
                    "for" => ForKeyword,
                    "while" => WhileKeyword,
                    "do" => DoKeyword,
                    "break" => BreakKeyword,
                    "continue" => ContinueKeyword,
                    _ => Identifier
                };
            }

            return Invalid;
        }
    }
}