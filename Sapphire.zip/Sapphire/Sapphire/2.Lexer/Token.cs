﻿namespace Sapphire.XLexer
{
    using Sapphire.Misc;
    using Sapphire.Resolver;
    using System.Diagnostics;

    [DebuggerDisplay("{Name} ({Type})")]
    public sealed record Token(string Value, string Type, SourceLocation Location)
    {
        public Identifier ToIdentifier()
        {
            if (Type != TokenTypes.Identifier)
                throw new InvalidOperationException($"Cannot convert token '{Value}' of type {Type} to Identifier at {Location}"
);

            return new Identifier(Value, Value, Location);
        }

        public override string ToString() => $"{Type} '{Value}' @ {Location}";

    }
}
